[![PHP Codeception Tests](https://github.com/humhub/content-bookmarks/actions/workflows/php-test.yml/badge.svg)](https://github.com/humhub/content-bookmarks/actions/workflows/php-test.yml)

# Content Bookmarks

The 'Content Bookmarks' module offers an easy way to save interesting content found in the network. Each user can access their individual bookmarks from their own profile. It enables users, for example, to keep a list of contributions that are particularly worth reading or simply save a discussion for future participation. 

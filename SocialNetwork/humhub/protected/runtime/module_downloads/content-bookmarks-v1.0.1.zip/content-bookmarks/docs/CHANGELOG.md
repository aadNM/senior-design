Changelog
=========

1.0.1 (June 13, 2021)
---------------------
- Enh #5: Display status messages on add/remove bookmarks
- Fix #6: Fix visibility of private bookmarked content of friends
- Fix #12, #13: Prevent crashing on global contents (not in a container)


1.0.0 (March 24, 2021)
----------------------
- Enh: Inital release

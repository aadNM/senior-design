<?php
return array (
  'Bookmarked' => 'Dodano zakładkę',
  'Bookmarks' => 'Zakładki',
  'Content successfully bookmarked. You can access it directly from your profile.' => 'Treść dodana do zakładek. Możesz się do niej dostać bezpośrednio ze swojego profilu.',
  'Content successfully removed from bookmarks.' => 'Treść poprawnie usunięta z zakładek.',
  'Invalid content id given!' => 'Podano niepoprawne id treści!',
  'Remove from bookmarks' => 'Usuń z zakładek',
  'Save as bookmark' => 'Zapisz jako zakładka',
  'You cannot bookmark this content!' => 'Nie możesz dodać tej treści do zakładek!',
);

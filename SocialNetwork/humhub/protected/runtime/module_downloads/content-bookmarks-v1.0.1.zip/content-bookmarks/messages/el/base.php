<?php
return array (
  'Bookmarked' => 'Προστέθηκε στους Σελιδοδείκτες',
  'Bookmarks' => 'Σελιδοδείκτες',
  'Content successfully bookmarked. You can access it directly from your profile.' => 'Το περιεχόμενο προστέθηκε επιτυχώς στους σελιδοδείκτες. Μπορείτε να το δείτε απευθείας από το προφίλ σας.',
  'Content successfully removed from bookmarks.' => 'Το περιεχόμενο αφαιρέθηκε επιτυχώς από τους σελιδοδείκτες',
  'Invalid content id given!' => 'Μη έγκυρο αναγνωριστικό ID περιεχομένου!',
  'Remove from bookmarks' => 'Διαγραφή από τους σελιδοδείκτες',
  'Save as bookmark' => 'Αποθήκευση ως σελιδοδείκτης',
  'You cannot bookmark this content!' => 'Δεν μπορείτε να δημιουργήσετε σελιδοδείκτη από αυτό το περιεχόμενο!',
);

<?php
return array (
  'Bookmarked' => 'Favorito',
  'Bookmarks' => 'Favoritos',
  'Content successfully bookmarked. You can access it directly from your profile.' => '',
  'Content successfully removed from bookmarks.' => '',
  'Invalid content id given!' => 'Informado ID de conteúdo inválido!',
  'Remove from bookmarks' => 'Remover dos favoritos',
  'Save as bookmark' => 'Salvar como favorito',
  'You cannot bookmark this content!' => '',
);

<?php
return array (
  'Bookmarked' => 'Bokmärkt',
  'Bookmarks' => 'Bokmärken',
  'Content successfully bookmarked. You can access it directly from your profile.' => '',
  'Content successfully removed from bookmarks.' => '',
  'Invalid content id given!' => 'Felaktigt innehålls id angivet!',
  'Remove from bookmarks' => 'Ta bort bokmärke',
  'Save as bookmark' => 'Spara som bokmärke',
  'You cannot bookmark this content!' => '',
);

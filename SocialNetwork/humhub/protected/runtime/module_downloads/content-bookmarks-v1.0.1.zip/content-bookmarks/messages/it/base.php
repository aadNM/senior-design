<?php
return array (
  'Bookmarked' => 'Segnalibro aggiunto',
  'Bookmarks' => 'Segnalibri',
  'Content successfully bookmarked. You can access it directly from your profile.' => '',
  'Content successfully removed from bookmarks.' => '',
  'Invalid content id given!' => 'Il Content id fornito non è valido!',
  'Remove from bookmarks' => 'Rimuovi dai segnalibri',
  'Save as bookmark' => 'Aggiungi segnalibro',
  'You cannot bookmark this content!' => '',
);

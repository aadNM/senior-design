<?php
return array (
  'Bookmarked' => 'Marcado como favorito',
  'Bookmarks' => 'Favoritos',
  'Content successfully bookmarked. You can access it directly from your profile.' => 'Contenido incluido con éxito en favoritos. Puedes acceder a él directamente desde tu perfil.',
  'Content successfully removed from bookmarks.' => 'Contenido eliminado con éxito de los favoritos.',
  'Invalid content id given!' => '¡Se ha proporcionado un identificador de contenido inválido!',
  'Remove from bookmarks' => 'Quitar de favoritos',
  'Save as bookmark' => 'Guardar como favorito',
  'You cannot bookmark this content!' => '¡No puedes incluir este contenido en los favoritos!',
);

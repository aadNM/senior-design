<?php
return array (
  'Bookmarked' => 'บุ๊คมาร์ค',
  'Bookmarks' => 'ที่คั่นหนังสือ',
  'Content successfully bookmarked. You can access it directly from your profile.' => 'บุ๊กมาร์กเนื้อหาเรียบร้อยแล้ว คุณสามารถเข้าถึงได้โดยตรงจากโปรไฟล์ของคุณ',
  'Content successfully removed from bookmarks.' => 'นำเนื้อหาออกจากบุ๊กมาร์กเรียบร้อยแล้ว',
  'Invalid content id given!' => 'ระบุ ID เนื้อหาไม่ถูกต้อง!',
  'Remove from bookmarks' => 'นำออกจากบุ๊กมาร์ก',
  'Save as bookmark' => 'บันทึกเป็นบุ๊คมาร์ค',
  'You cannot bookmark this content!' => 'คุณไม่สามารถบุ๊กมาร์กเนื้อหานี้ได้!',
);

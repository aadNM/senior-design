<?php
return array (
  'Bookmarked' => 'Mit Lesezeichen',
  'Bookmarks' => 'Lesezeichen',
  'Content successfully bookmarked. You can access it directly from your profile.' => 'Inhalt erfolgreich mit einem Lesezeichen versehen. Du kannst nun jederzeit direkt aus deinem Profil darauf zugreifen!',
  'Content successfully removed from bookmarks.' => 'Lesezeichen erfolgreich entfernt.',
  'Invalid content id given!' => 'Ungültige Inhalts-ID angegeben!',
  'Remove from bookmarks' => 'Lesezeichen entfernen',
  'Save as bookmark' => 'Lesezeichen setzen',
  'You cannot bookmark this content!' => 'Dieser Inhalt kann nicht mit einem Lesezeichen versehen werden!',
);

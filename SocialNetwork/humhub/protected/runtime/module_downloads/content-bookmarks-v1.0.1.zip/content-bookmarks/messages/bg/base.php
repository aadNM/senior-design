<?php
return array (
  'Bookmarked' => 'Отбелязани',
  'Bookmarks' => 'Отметки',
  'Content successfully bookmarked. You can access it directly from your profile.' => '',
  'Content successfully removed from bookmarks.' => '',
  'Invalid content id given!' => 'Даден е невалиден идентификатор на съдържанието!',
  'Remove from bookmarks' => 'Премахване от отметки',
  'Save as bookmark' => 'Запази като отметка',
  'You cannot bookmark this content!' => '',
);

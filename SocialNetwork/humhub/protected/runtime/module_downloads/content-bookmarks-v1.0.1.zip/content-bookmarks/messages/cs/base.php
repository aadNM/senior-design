<?php
return array (
  'Bookmarked' => '',
  'Bookmarks' => '',
  'Content successfully bookmarked. You can access it directly from your profile.' => '',
  'Content successfully removed from bookmarks.' => '',
  'Invalid content id given!' => 'Vloženo chybé ID obsahu',
  'Remove from bookmarks' => '',
  'Save as bookmark' => '',
  'You cannot bookmark this content!' => '',
);

<?php
return array (
  'Bookmarked' => 'Bladwijzer gemaakt',
  'Bookmarks' => 'Bladwijzer',
  'Content successfully bookmarked. You can access it directly from your profile.' => 'Bladwijzer gemaakt van deze informatie. Je hebt er rechtstreeks toegang toe vanuit je profiel.',
  'Content successfully removed from bookmarks.' => 'Informatie succesvol verwijderd uit bladwijzers.',
  'Invalid content id given!' => 'Ongeldige informatie-ID opgegeven!',
  'Remove from bookmarks' => 'Verwijderen uit bladwijzers',
  'Save as bookmark' => 'Opslaan als bladwijzer',
  'You cannot bookmark this content!' => 'U kunt van deze informatie geen bladwijzer maken!',
);

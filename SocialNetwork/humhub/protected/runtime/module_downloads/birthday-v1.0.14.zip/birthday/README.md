[![Build Status](https://travis-ci.org/humhub/humhub-modules-birthday.svg?branch=master)](https://travis-ci.org/humhub/humhub-modules-birthday)

# Birthday Widget

Show your appreciation to your colleagues and brighten their day with warm wishes.

## Feature Overview

- Adds a widget to your dashboard with upcoming birthdays
- Period for which the upcoming birthdays should be displayed is configurable
- Users can hide their year of birth / age
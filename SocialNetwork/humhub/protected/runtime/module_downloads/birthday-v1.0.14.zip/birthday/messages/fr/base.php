<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Anniversaires</strong> dans les {days} prochains jours',
  'Back to modules' => 'Retour aux modules',
  'Birthday Module Configuration' => 'Configuration du module <strong>anniversaires</strong>',
  'In {days} days' => 'Dans {days} jours',
  'Save' => 'Enregistrer',
  'The group id of the group that should be exluded.' => 'L\'ID du groupe qui doit être exclu.',
  'The number of days future birthdays will be shown within.' => 'Le nombre de jours avant qu\'un anniversaire soit affiché.',
  'Tomorrow' => 'Demain',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Vous pouvez spécifier le nombre de jours avant qu\'un anniversaire soit affiché.',
  'becomes {years} years old.' => 'aura {years} ans.',
  'today' => 'aujourd\'hui',
);

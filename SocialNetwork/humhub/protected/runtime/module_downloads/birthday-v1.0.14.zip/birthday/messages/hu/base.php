<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Születésnapok</strong>',
  'Back to modules' => 'Vissza a modulokhoz',
  'Birthday Module Configuration' => 'Születésnap modul konfiguráció',
  'In {days} days' => '{days} napon belül',
  'Save' => 'Mentés',
  'The group id of the group that should be exluded.' => 'A kihagyandó csoport csoportazonosítója.',
  'The number of days future birthdays will be shown within.' => 'Hány napig mutassa a jövőbeni születésnapokat.',
  'Tomorrow' => 'Holnap',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Itt beállíthatod, hogy hány napig mutassa a jövőbeni születésnapokat.',
  'becomes {years} years old.' => '{years} éves lesz.',
  'today' => 'ma',
);

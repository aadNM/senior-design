<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '次の{days}の日以内に<strong>誕生日 strong&gt;</strong>',
  'Back to modules' => 'モジュールへ戻る',
  'Birthday Module Configuration' => '誕生日モジュールの設定',
  'In {days} days' => '{days}日以内',
  'Save' => '保存',
  'The group id of the group that should be exluded.' => '除外するグループのグループID。',
  'The number of days future birthdays will be shown within.' => '将来の誕生日が表示されます。',
  'Tomorrow' => '明日',
  'You may configure the number of days within the upcoming birthdays are shown.' => '今後の誕生日の日数を設定することができます。',
  'becomes {years} years old.' => '{years}歳になるでしょう。',
  'today' => '今日',
);

<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Syntymäpäivät</strong> seuraavan {days} päivän aikana',
  'Back to modules' => 'Takaisin',
  'Birthday Module Configuration' => '<strong>Syntymäpäivä</strong> laajennuksen hallinta',
  'In {days} days' => '{days} päivän päästä',
  'Save' => 'Tallenna',
  'The group id of the group that should be exluded.' => 'Ryhmä, joka tulisi jättää pois.',
  'The number of days future birthdays will be shown within.' => 'Voit määrittää kuinka monta päivää ennen syntymäpäivät näkyvät.',
  'Tomorrow' => 'Huomenna',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Voit määrittää kuinka monta päivää ennen syntymäpäivät näkyvät.',
  'becomes {years} years old.' => 'täyttää {years} vuotta.',
  'today' => 'tänään',
);

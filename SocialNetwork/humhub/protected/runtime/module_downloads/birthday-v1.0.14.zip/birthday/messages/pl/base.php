<?php
return array (
  '<strong>Birthdays</strong> within the next {days} days' => '<strong>Urodziny</strong> w nabliższych {days} dniach',
  'Back to modules' => 'Powrót do modułów',
  'Birthday Module Configuration' => 'Konfiguracja modułu Birthday',
  'In {days} days' => 'Za {days} dni',
  'Save' => 'Zapisz',
  'The group id of the group that should be exluded.' => 'ID grupy która powinna zostać wykluczona.',
  'The number of days future birthdays will be shown within.' => 'Liczba dni do przodu z przeciągu których mają być wyświetlane urodziny.',
  'Tomorrow' => 'Jutro',
  'You may configure the number of days within the upcoming birthdays are shown.' => 'Możesz skonfigurować liczbę dni kiedy będą pokazywane nadchodzące urodziny.',
  'becomes {years} years old.' => 'ma {years} lat.',
  'today' => 'dzisiaj',
);

FireBase - Push Notifications
=============================

** Note this module in beta stage yet **

This modules enables Push notifications using the [Google Firebase Messaging](https://firebase.google.com/) service.

1.0.1  (January 21, 2021)
-------------------------

- Fix: Initialize firebase only if module was configured
- Enh: Updated CHANGELOG


1.0.0  (December 17, 2019)
-------------------------
Initial release
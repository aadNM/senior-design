# Installing & Setup
1. Download via git or normal download or use the marketplace.
2. Upload the zip file `humhub-weather-module-master.zip` to your server under `/protected/modules` and rename it `weather`
3. Enable the module via `ACP > Modules > Modules List`
4. In `ACP > Weather Settings` place your [WeatherWidget.io](https://weatherwidget.io/) information in the configuration fields then save.

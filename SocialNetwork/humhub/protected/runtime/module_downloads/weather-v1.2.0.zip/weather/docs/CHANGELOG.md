# Changelogs
Release v1.2.0: (*12/18/2020*)
- Enh: Add sortOrder configurations
- Enh: Add sortOrder Module settings
- Enh: Fix sortOrder + addEntry migration
- Enh: Moved old changlogs to `/docs/old`

> Note: Older change logs have been moved to [here](https://github.com/GreenMeteor/humhub-weather-module/blob/dev/docs/old/CHANGELOG.md)

<?php

return [
    '<strong>Weather</strong>' => '<strong>Météo</strong> ',
    '<strong>Weather</strong> module configuration' => 'Configuration du module <strong>Météo</strong>',
    'Save' => 'Enregistrer',
    'Weather Settings' => 'Paramètres météo',
    'Forecast7 Weather URL:' => 'URL Météo Forecast 7:',
    'Location where you\'re located:' => 'Votre emplacement:',
    'e.g. New York' => 'ex. Paris',
    'e.g. https://forecast7.com/{language}/{id}/{location}/ or https://forecast7.com/{language}/{id}/{location}/?unit=us' => 'ex. https://forecast7.com/{language}/{id}/{location}/ ou https://forecast7.com/{language}/{id}/{location}/?unit=us',
    '{location} WEATHER' => 'METEO {location}',
];

<?php
    return [
        '<strong>Weather</strong>' => '<strong>Weather</strong> ',
        'Weather Settings' => 'Weather Settings',
        'Weather URL:' => 'Weather URL:',
        '<strong>Weather</strong> module configuration' => '<strong>Weather</strong> module configuration',
        'Save' => 'Save',
        '{language}' => 'en',
    ];

<?php

return [
    '<strong>Weather</strong>' => '',
    '<strong>Weather</strong> module configuration' => '',
    'Forecast7 Weather URL:' => '',
    'Location where you\'re located:' => '',
    'Save' => '',
    'Weather Settings' => '',
    'e.g. New York' => '',
    'e.g. https://forecast7.com/{language}/{id}/{location}/ or https://forecast7.com/{language}/{id}/{location}/?unit=us' => '',
    '{location} WEATHER' => '',
];

<?php

return [
    '<strong>Weather</strong>' => '<strong>Weather</strong>',
    '<strong>Weather</strong> module configuration' => '<strong>Weather</strong> modül yapılandırması',
    'Save' => 'Kaydet',
    'Weather Settings' => 'Weather Ayarlar',
    'Forecast7 Weather URL:' => '',
    'Location where you\'re located:' => '',
    'e.g. New York' => '',
    'e.g. https://forecast7.com/{language}/{id}/{location}/ or https://forecast7.com/{language}/{id}/{location}/?unit=us' => '',
    '{location} WEATHER' => '',
];


## [HumHub](https://www.humhub.org/en) Weather Module
[![CLA assistant](https://cla-assistant.io/readme/badge/GreenMeteor/humhub-weather-module)](https://cla-assistant.io/GreenMeteor/humhub-weather-module)

Create a Weather widget on your Dashboard.

> Note: Forecast7 & WeatherWidget.io are external services that provide the code and weather forcast that is placed within your HumHub's sidebar.

### __Product Distributors:__
[@GreenMeteor](https://github.com/GreenMeteor)

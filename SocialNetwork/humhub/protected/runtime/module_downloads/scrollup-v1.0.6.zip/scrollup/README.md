# [HumHub](https://www.humhub.org/en) Scroll Up Module

With this module, when enabled, creates a button action that allows you to instantly scroll up on your dashboard after loading content.

### **Product Distributors:**

[@GreenMeteor](https://github.com/GreenMeteor)

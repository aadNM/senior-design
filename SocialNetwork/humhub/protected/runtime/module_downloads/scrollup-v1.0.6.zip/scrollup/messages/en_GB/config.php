<?php
    return [
        '<strong>Discord</strong> Chat' => '<strong>Discord</strong> Chat',
        'Position:' => 'Position:',
        'Color:' => 'Color:',
        'Invalid color!' => 'Invalid color!',
        'e.g: <code>left: 30px;</code> or <code>right: 30px;</code> (default: calculated center of stream sidebar' => 'e.g: <code>left: 30px;</code> or <code>right: 30px;</code> (default: calculated center of stream sidebar',
        'e.g. <code>#000000</code> (default: your themes @default color variable).' => 'e.g. <code>#000000</code> (default: your themes @default color variable).',
        '<strong>Scroll Up</strong> module configuration' => '<strong>Scroll Up</strong> module configuration',
        'Select color ...' => 'Select color ...',
        'Save' => 'Save',
    ];

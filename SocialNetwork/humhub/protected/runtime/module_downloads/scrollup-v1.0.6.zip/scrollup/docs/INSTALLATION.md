## Installing/Setup
This module is one of the easiest and simple modules out there
- Download via [git](https://github.com/GreenMeteor/humhub-scrollup-module.git) or [marketplace](https://www.humhub.com/en/marketplace/scrollup/)
- Go to `Admin Panel > Modules > Module List`
- Enable the `Scroll Up` module

## Changelogs

Date: *8/8/2020*
- Enh: Styling changes; JS  support an array of classes to append to; You can choose between a default position and position from the right for such cases like a wiki  page 

Date: *5/5/2020*
- Enh: Increased minimum HumHub version to `v1.4.x`

Date: *4/24/2020*
- Fix: ConfigureForm not validated

Date: *4/23/2020*
- Fix: Displaying scroll button in transpant when config options aren't filled in

Date: *4/18/2020*
- Enh: Custom Color
- Fix: Event param errors

Date: *4/13/2020*
- Enh: Position Switch Option
- Chg: New version

Date: *4/9/2020*
- Enh: Remove JS file completely
- Fix: Pjax loading issues
- Enh: Upgraded Version v1.0.1
- Enh: Updated CHANGELOG.md

Date: *4/4/2020*
- Enh: Created INSTALLATION.md
- Enh: Update README.md
- Enh: Created CHANGELOG.md

## End User Manual
This module is very simple to use

### Configurations
- Custom Positions: `top-left`, `top-right`, `bottom-left`, and `bottom-right`
- Custom Color: `#000000`

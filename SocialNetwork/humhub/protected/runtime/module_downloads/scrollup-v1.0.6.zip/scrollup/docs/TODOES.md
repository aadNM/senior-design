# To do list
- ~Add config option for scroll button position~ (Impelmented in [#6](https://github.com/GreenMeteor/humhub-scrollup-module/pull/6))
- ~Add config option for custom color~

<?php
/**
 * @link https://www.humhub.org/
 * @copyright Copyright (c) 2020 HumHub GmbH & Co. KG
 * @license https://www.humhub.com/licences
 */

return [
    'modules' => ['twofa'],
    'fixtures' => [
        'default',
        //'twofa' => \tests\codeception\fixtures\TwofaFixture::class
    ]
];

<?php

return [
    '<strong>Two-factor</strong> authentication' => '',
    'A confirmation code hast just been sent to your email address. Please enter the code from the email in order to proceed.' => '',
    'Authentication method' => '',
    'Code' => '',
    'Code is not valid!' => '',
    'Code:' => '',
    'Date and time:' => '',
    'Disable two-factor authentication (not recommended)' => '',
    'Email' => '',
    'Hello {displayName}!' => '',
    'Log out' => '',
    'Open the two-factor authentication app on your device to view your authentication code and verify your identity.' => '',
    'Pin code' => '',
    'Please enter your verifying code.' => '',
    'Time-based one-time passwords (e.g. Google Authenticator)' => '',
    'Two-Factor Authentication' => '',
    'Verify' => '',
    'Verifying code is not valid!' => '',
    'Your account is secured by a two-factor authentication system. Please use the following code to proceed.' => '',
    'Your login verification code' => '',
];

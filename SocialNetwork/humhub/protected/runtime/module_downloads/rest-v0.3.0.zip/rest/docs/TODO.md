# TODO

- Login As (Remove hardcoded user id 1)

## To discuss

- API Endpoint  /api vs /rest
- CamelCase vs snake_Case vs spinal-case in response
- Complexity of responses (e.g. first comments of a posts)
- Scopes and Permissions
- Core integration, structure of modules API pack
- If integrated core, use also for common requests (via Session) for some AJAX calls?
- Date Formats





<?php
/**
 * @link https://www.humhub.org/
 * @copyright Copyright (c) 2019 HumHub GmbH & Co. KG
 * @license https://www.humhub.com/licences
 */

namespace humhub\modules\rest\controllers\cfiles;

use humhub\modules\rest\components\BaseController;

class CfilesController extends BaseController
{
    public static $moduleId = 'cfiles';
}
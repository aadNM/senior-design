<?php
/**
 * @link https://www.humhub.org/
 * @copyright Copyright (c) 2018 HumHub GmbH & Co. KG
 * @license https://www.humhub.com/licences
 */

namespace humhub\modules\rest\controllers\user;

use humhub\modules\rest\components\BaseController;


/**
 * Class InviteController
 */
class InviteController extends BaseController
{

    public function actionIndex()
    {
        return ["not implemeted"];
    }

}
<?php
return array (
  '<strong>API</strong> Configuration' => '<strong>API</strong> -configuratie',
  'Enabled for all registered users' => 'Ingeschakeld voor alle geregistreerde gebruikers',
  'JWT Key' => 'JWT-sleutel',
);

<?php
return array (
  '<strong>API</strong> Configuration' => '<strong>API</strong> beállítás',
  'Enabled for all registered users' => 'Engedélyezés az összes felhasználónak',
  'JWT Key' => 'JWT kulcs',
);

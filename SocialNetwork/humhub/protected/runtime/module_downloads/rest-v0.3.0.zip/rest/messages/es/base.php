<?php
return array (
  '<strong>API</strong> Configuration' => 'Configuración de <strong>API</strong>',
  'Enabled for all registered users' => 'Habilitado para todos los usuarios registrados',
  'JWT Key' => 'Clave JWT',
);

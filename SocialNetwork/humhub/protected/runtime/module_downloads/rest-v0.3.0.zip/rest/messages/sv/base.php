<?php

return [
    '<strong>API</strong> Configuration' => '',
    'Enabled for all registered users' => '',
    'JWT Key' => '',
];

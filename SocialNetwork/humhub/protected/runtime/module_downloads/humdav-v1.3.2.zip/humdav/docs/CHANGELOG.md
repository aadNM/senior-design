Changelog
=========

1.3.2 (October 28, 2021)
---------------------
- Enh: This module is now available in HumHum Marketplace.
- Chng: Removal of the update mechanism.
<?php

return [
    'modules' => ['termsbox'],
    'fixtures' => ['default']
];

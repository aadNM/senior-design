Changelog
=========

1.1.0  (September 23, 2021)
----------------------------
- Fix #4: Don't show termsbox when user must change password

1.0.6  (August 26, 2021)
------------------------
- Enh #3: Update logout url to POST method

1.0.5  (April 06, 2020)
---------------------
- Fix: Markdown files not attached
- Cng: Updated HumHub min version to 1.3

1.0.4  (October 16, 2019)
---------------------
- Enh: 1.4 nonce compatibility

1.0.3  (July 2, 2018)
---------------------
- Fix: PHP 7.2 compatibility issues


1.0.2  (October 11, 2017)
------------------------_
- Enh: Added possiblity to hide users when terms not accepted yet
- Enh: Moved terms accepted flag to the user model to improve lookup speed 

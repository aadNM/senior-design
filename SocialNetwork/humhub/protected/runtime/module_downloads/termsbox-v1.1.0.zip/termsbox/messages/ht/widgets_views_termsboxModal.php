<?php
return array (
  'Accept' => 'Aksepte',
  'Decline' => '',
);

<?php
return array (
  'Accept' => 'Pranoj',
  'Decline' => '',
);

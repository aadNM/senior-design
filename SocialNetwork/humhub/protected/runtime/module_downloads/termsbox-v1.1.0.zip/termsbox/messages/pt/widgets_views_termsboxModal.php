<?php
return array (
  'Accept' => 'Aceitar',
  'Decline' => 'Rejeitar',
);

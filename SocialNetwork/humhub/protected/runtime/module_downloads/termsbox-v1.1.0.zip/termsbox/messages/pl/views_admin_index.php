<?php
return array (
  'Back to modules' => 'Powrót do modułów',
  'Save' => 'Zapisz',
  'Terms Box Configuration' => 'Konfiguracja skrzynki warunków',
);

<?php
return array (
  'Active' => 'Activado',
  'Content' => 'Conteúdo',
  'Hide users which not accepted the terms (Note: May require search index rebuild)' => '',
  'Mark as unseen for all users' => 'Marcar como invisível para todos os utilizadores',
  'Please Read and Agree to our Terms & Conditions' => '',
  'Show terms as modal' => '',
  'Statement' => '',
  'Terms & Conditions' => '',
  'Title' => 'Título',
);

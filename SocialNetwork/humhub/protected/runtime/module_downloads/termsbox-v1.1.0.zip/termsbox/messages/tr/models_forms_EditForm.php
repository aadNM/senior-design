<?php
return array (
  'Active' => 'Aktif',
  'Content' => 'İçerik',
  'Hide users which not accepted the terms (Note: May require search index rebuild)' => '',
  'Mark as unseen for all users' => 'Tüm kullanıcılar için işaretle olarak görünmeyen',
  'Please Read and Agree to our Terms & Conditions' => '',
  'Show terms as modal' => '',
  'Statement' => '',
  'Terms & Conditions' => '',
  'Title' => 'Başlık',
);

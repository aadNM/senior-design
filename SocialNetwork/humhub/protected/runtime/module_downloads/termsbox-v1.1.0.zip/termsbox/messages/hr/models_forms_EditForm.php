<?php
return array (
  'Active' => 'Aktivno',
  'Content' => 'Sadržaj',
  'Hide users which not accepted the terms (Note: May require search index rebuild)' => '',
  'Mark as unseen for all users' => 'Označi kao nepročitano za sve korisnike',
  'Please Read and Agree to our Terms & Conditions' => '',
  'Show terms as modal' => '',
  'Statement' => '',
  'Terms & Conditions' => '',
  'Title' => 'Naziv',
);

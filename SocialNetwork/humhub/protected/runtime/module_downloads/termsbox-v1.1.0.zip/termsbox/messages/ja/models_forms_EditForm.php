<?php
return array (
  'Active' => 'アクティブ',
  'Content' => 'コンテンツ',
  'Hide users which not accepted the terms (Note: May require search index rebuild)' => '',
  'Mark as unseen for all users' => 'すべてのユーザーに見えない状態としてマーク',
  'Please Read and Agree to our Terms & Conditions' => '',
  'Show terms as modal' => '',
  'Statement' => '',
  'Terms & Conditions' => '',
  'Title' => 'タイトル',
);

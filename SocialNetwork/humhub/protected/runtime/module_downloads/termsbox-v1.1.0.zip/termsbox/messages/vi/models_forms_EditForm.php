<?php
return array (
  'Active' => 'Hoạt động',
  'Content' => 'Nội dung',
  'Hide users which not accepted the terms (Note: May require search index rebuild)' => '',
  'Mark as unseen for all users' => 'Đánh dấu \'chưa xem\' cho tất cả người dùng',
  'Please Read and Agree to our Terms & Conditions' => '',
  'Show terms as modal' => '',
  'Statement' => '',
  'Terms & Conditions' => '',
  'Title' => 'Tiêu đề',
);

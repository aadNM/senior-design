<?php
return array (
  'Back to modules' => 'Назад к модулям',
  'Save' => 'Сохранить',
  'Terms Box Configuration' => '',
);

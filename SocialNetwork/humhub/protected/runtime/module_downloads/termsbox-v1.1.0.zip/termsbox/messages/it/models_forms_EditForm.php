<?php
return array (
  'Active' => 'Attivo',
  'Content' => 'Contenuto',
  'Hide users which not accepted the terms (Note: May require search index rebuild)' => 'Nascondi gli utenti che non hanno accettato i termini (Nota: potrebbe richiedere la ricostruzione dell\'indice di ricerca)',
  'Mark as unseen for all users' => 'Marca come non visto per tutti gli utenti',
  'Please Read and Agree to our Terms & Conditions' => 'Si prega di leggere e accettare i nostri Termini e condizioni',
  'Show terms as modal' => 'Mostra termini come modali',
  'Statement' => 'dichiarazione',
  'Terms & Conditions' => 'Termini &amp; Condizioni',
  'Title' => 'Titolo',
);

<?php
return array (
  'Accept' => 'Accepta',
  'Decline' => 'No hi assistiré',
);

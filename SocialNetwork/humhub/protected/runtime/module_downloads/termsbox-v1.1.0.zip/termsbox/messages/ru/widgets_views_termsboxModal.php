<?php
return array (
  'Accept' => 'Активировать',
  'Decline' => 'Отказать',
);

<?php
return array (
  'Back to modules' => 'กลับไปที่โมดูล',
  'Save' => 'บันทึก',
  'Terms Box Configuration' => 'การกำหนดค่ากล่องข้อกำหนด',
);

<?php
return array (
  'Accept' => 'Aceptar',
  'Decline' => 'Declinar',
);

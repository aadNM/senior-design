<?php
return array (
  'Accept' => '동의하기',
  'Decline' => '',
);

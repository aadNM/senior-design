<?php
return array (
  'Accept' => 'súhlasiť',
  'Decline' => '',
);

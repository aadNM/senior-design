<?php
return array (
  'Accept' => 'Sprejmi',
  'Decline' => '',
);

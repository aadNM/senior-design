<?php
return array (
  'Active' => 'Aktiv',
  'Content' => 'Innehåll',
  'Hide users which not accepted the terms (Note: May require search index rebuild)' => 'Dölj användare som inte accepterade villkoren (OBS: kan kräva att sökindexet byggs om)',
  'Mark as unseen for all users' => 'Markera som osedd för alla användare',
  'Please Read and Agree to our Terms & Conditions' => 'Läs och acceptera våra allmänna villkor',
  'Show terms as modal' => 'Visa villkor modalt',
  'Statement' => 'Uttalande',
  'Terms & Conditions' => 'Allmänna villkor',
  'Title' => 'Titel',
);

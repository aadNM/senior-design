<?php
return array (
  'Back to modules' => '返回模块',
  'Save' => '保存',
  'Terms Box Configuration' => '',
);

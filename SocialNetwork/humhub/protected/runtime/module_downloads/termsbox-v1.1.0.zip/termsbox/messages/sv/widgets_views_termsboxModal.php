<?php
return array (
  'Accept' => 'Acceptera',
  'Decline' => 'Avböj',
);

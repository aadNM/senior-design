<?php
return array (
  'Back to modules' => 'Modüllere dön',
  'Save' => 'Kaydet',
  'Terms Box Configuration' => '',
);

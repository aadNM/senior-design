<?php
return array (
  'Accept' => 'پذیرش',
  'Decline' => 'انصراف',
);

<?php
return array (
  'Back to modules' => 'Tornar a os modulos',
  'Save' => 'Uložit',
  'Terms Box Configuration' => '',
);

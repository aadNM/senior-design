<?php

return [
    'Back to modules' => '',
    'Save' => '',
    'Terms Box Configuration' => '',
];

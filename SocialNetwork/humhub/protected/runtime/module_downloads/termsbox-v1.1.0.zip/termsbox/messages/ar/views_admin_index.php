<?php
return array (
  'Back to modules' => 'العودة للموديولات',
  'Save' => 'حفظ',
  'Terms Box Configuration' => '',
);

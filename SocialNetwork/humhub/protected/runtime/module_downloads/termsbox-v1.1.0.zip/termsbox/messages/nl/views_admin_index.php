<?php
return array (
  'Back to modules' => 'Terug naar modules',
  'Save' => 'Opslaan',
  'Terms Box Configuration' => 'Configuratie van de voorwaardenbox',
);

<?php
return array (
  'Back to modules' => 'Tilbake til moduler',
  'Save' => 'Lagre',
  'Terms Box Configuration' => '',
);

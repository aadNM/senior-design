<?php
return array (
  'Back to modules' => 'Vissza a modulokhoz',
  'Save' => 'Mentés',
  'Terms Box Configuration' => 'Feltételek mező beállítása',
);

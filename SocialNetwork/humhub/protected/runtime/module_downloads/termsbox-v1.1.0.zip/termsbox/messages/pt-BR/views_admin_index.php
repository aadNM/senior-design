<?php
return array (
  'Back to modules' => 'Voltar aos módulos',
  'Save' => 'Salvar',
  'Terms Box Configuration' => '',
);

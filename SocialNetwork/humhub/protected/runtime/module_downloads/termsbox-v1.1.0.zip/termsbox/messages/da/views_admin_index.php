<?php
return array (
  'Back to modules' => 'Tilbage til moduler',
  'Save' => 'Gem',
  'Terms Box Configuration' => '',
);

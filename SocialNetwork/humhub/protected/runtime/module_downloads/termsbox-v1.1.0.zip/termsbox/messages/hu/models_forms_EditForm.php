<?php
return array (
  'Active' => 'Aktív',
  'Content' => 'Tartalom',
  'Hide users which not accepted the terms (Note: May require search index rebuild)' => 'Rejtse el azokat a felhasználókat akik nem fogadták el a felhasználási feltételeket (Megjegyzés: A keresési index újjáépítése szükséges)',
  'Mark as unseen for all users' => 'Jelölje meg "Nem olvasottnak" minden felhasználónak',
  'Please Read and Agree to our Terms & Conditions' => 'Kérjük, hogy olvassa el és fogadja el az Általános felhasználási feltételeinket',
  'Show terms as modal' => 'Feltételek mutatása mint modal ablak',
  'Statement' => 'Nyilatkozat',
  'Terms & Conditions' => 'Felhasználási feltételek',
  'Title' => 'Cím',
);

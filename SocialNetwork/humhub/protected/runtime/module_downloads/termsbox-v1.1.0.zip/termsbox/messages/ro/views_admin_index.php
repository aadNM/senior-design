<?php
return array (
  'Back to modules' => 'Înapoi la module',
  'Save' => 'Salvează',
  'Terms Box Configuration' => '',
);

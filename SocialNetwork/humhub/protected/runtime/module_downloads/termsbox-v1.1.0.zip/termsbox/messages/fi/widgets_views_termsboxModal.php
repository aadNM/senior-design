<?php
return array (
  'Accept' => 'Hyväksy',
  'Decline' => 'Hylkää',
);

<?php
return array (
  'Accept' => 'Accepter',
  'Decline' => 'Afslå',
);

<?php
return array (
  'Accept' => 'Pieņemt',
  'Decline' => 'Noraidīt',
);

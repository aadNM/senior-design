<?php
return array (
  'Accept' => 'קבל',
  'Decline' => 'דחה',
);

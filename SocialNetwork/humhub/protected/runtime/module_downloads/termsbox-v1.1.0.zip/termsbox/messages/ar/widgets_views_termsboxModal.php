<?php
return array (
  'Accept' => 'موافقة',
  'Decline' => 'رفض',
);

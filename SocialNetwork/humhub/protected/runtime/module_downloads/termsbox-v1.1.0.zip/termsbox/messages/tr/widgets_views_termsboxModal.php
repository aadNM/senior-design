<?php
return array (
  'Accept' => 'Onayla',
  'Decline' => 'Reddet',
);

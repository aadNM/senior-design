<?php
return array (
  'Active' => 'Активен',
  'Content' => 'Съдържание',
  'Hide users which not accepted the terms (Note: May require search index rebuild)' => 'Скриване на потребители, които не са приели условията (Забележка: Може да се наложи възстановяване на индекса за търсене)',
  'Mark as unseen for all users' => 'Маркирайте като невидян за всички потребители',
  'Please Read and Agree to our Terms & Conditions' => 'Моля, прочетете и приемете нашите Общи условия',
  'Show terms as modal' => 'Показвайте термините като модални',
  'Statement' => 'Изявление',
  'Terms & Conditions' => 'Правила и условия',
  'Title' => 'Заглавие',
);

<?php
return array (
  'Accept' => 'Chấp nhận',
  'Decline' => 'Từ chối',
);

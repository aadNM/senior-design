<?php
return array (
  'Accept' => 'Akseptér',
  'Decline' => 'Avslå',
);

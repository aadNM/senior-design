<?php
return array (
  'Accept' => 'Accetta',
  'Decline' => 'Rifiuta',
);

<?php
return array (
  'Active' => 'คล่องแคล่ว',
  'Content' => 'เนื้อหา',
  'Hide users which not accepted the terms (Note: May require search index rebuild)' => 'ซ่อนผู้ใช้ที่ไม่ยอมรับเงื่อนไข (หมายเหตุ: อาจต้องสร้างดัชนีการค้นหาใหม่)',
  'Mark as unseen for all users' => 'ทำเครื่องหมายว่ามองไม่เห็นสำหรับผู้ใช้ทั้งหมด',
  'Please Read and Agree to our Terms & Conditions' => 'โปรดอ่านและยอมรับข้อกำหนดและเงื่อนไขของเรา',
  'Show terms as modal' => 'แสดงเงื่อนไขเป็นกิริยาช่วย',
  'Statement' => 'คำให้การ',
  'Terms & Conditions' => 'ข้อตกลงและเงื่อนไข',
  'Title' => 'หัวข้อ',
);

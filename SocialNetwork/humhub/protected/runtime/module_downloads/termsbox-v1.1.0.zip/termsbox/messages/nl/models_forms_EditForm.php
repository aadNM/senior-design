<?php
return array (
  'Active' => 'Actief',
  'Content' => 'Inhoud',
  'Hide users which not accepted the terms (Note: May require search index rebuild)' => 'Gebruikers verbergen die de voorwaarden niet hebben geaccepteerd (Opmerking: mogelijk moet de zoekindex opnieuw worden opgebouwd)',
  'Mark as unseen for all users' => 'Markeren als ongezien voor alle gebruikers',
  'Please Read and Agree to our Terms & Conditions' => 'Lees en ga akkoord met onze Algemene voorwaarden',
  'Show terms as modal' => 'Termen weergeven in modal',
  'Statement' => 'Declaratie',
  'Terms & Conditions' => 'Algemene voorwaarden',
  'Title' => 'Titel',
);

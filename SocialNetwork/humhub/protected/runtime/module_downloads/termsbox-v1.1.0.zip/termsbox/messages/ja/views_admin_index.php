<?php
return array (
  'Back to modules' => 'モジュールへ戻る',
  'Save' => '保存',
  'Terms Box Configuration' => '',
);

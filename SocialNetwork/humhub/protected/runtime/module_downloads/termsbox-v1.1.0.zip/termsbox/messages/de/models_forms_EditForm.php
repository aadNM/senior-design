<?php
return array (
  'Active' => 'Aktiv',
  'Content' => 'Inhalt',
  'Hide users which not accepted the terms (Note: May require search index rebuild)' => 'Benutzer ausblenden, die die Bedingungen nicht akzeptiert haben (Hinweis: Kann einen Neuaufbau des Suchindex erfordern)',
  'Mark as unseen for all users' => 'Für alle Benutzer als „ungesehen“ markieren',
  'Please Read and Agree to our Terms & Conditions' => 'Bitte lese und akzeptiere unsere AGBs',
  'Show terms as modal' => 'Bedingungen als modal anzeigen',
  'Statement' => 'Stellungnahme',
  'Terms & Conditions' => 'AGBs',
  'Title' => 'Titel',
);

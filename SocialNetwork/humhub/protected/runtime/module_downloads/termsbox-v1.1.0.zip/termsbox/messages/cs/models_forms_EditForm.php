<?php
return array (
  'Active' => 'Aktivovat',
  'Content' => 'Příspěvky',
  'Hide users which not accepted the terms (Note: May require search index rebuild)' => '',
  'Mark as unseen for all users' => 'Označit jako nepřečtené pro všechny uživatele',
  'Please Read and Agree to our Terms & Conditions' => '',
  'Show terms as modal' => '',
  'Statement' => '',
  'Terms & Conditions' => '',
  'Title' => 'Název',
);

<?php
return array (
  'Accept' => 'Akzeptieren',
  'Decline' => 'Ablehnen',
);

<?php
return array (
  'Accept' => 'Αποδέχομαι',
  'Decline' => 'Άρνηση',
);

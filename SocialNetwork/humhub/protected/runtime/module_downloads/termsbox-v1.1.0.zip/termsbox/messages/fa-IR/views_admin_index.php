<?php
return array (
  'Back to modules' => 'بازگشت‌ به ماژول‌‌ها',
  'Save' => 'ذخیره',
  'Terms Box Configuration' => '',
);

<?php
return array (
  'Accept' => 'Prihvati',
  'Decline' => 'Odbij',
);

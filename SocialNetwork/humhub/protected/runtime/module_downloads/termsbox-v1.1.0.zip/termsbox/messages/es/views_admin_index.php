<?php
return array (
  'Back to modules' => 'Volver a módulos',
  'Save' => 'Guardar',
  'Terms Box Configuration' => 'Configuración del módulo de Términos',
);

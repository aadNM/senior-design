<?php
return array (
  'Back to modules' => 'Indietro ai moduli',
  'Save' => 'Salva',
  'Terms Box Configuration' => 'Configurazione della casella dei termini',
);

<?php
return array (
  'Accept' => 'Menerima',
  'Decline' => 'Batal',
);

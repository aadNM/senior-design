<?php
return array (
  'Accept' => 'Aksepterer',
  'Decline' => '',
);

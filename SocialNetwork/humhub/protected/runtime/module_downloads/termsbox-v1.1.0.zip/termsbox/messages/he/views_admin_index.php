<?php
return array (
  'Back to modules' => '',
  'Save' => 'שמירה',
  'Terms Box Configuration' => '',
);

<?php
return array (
  'Accept' => 'ยอมรับ',
  'Decline' => 'ลดลง',
);

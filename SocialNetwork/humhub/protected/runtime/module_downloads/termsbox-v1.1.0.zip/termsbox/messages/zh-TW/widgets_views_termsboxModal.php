<?php
return array (
  'Accept' => '接受',
  'Decline' => '',
);

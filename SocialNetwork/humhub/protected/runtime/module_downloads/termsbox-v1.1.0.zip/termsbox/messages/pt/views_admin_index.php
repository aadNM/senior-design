<?php
return array (
  'Back to modules' => 'Voltar para os módulos',
  'Save' => 'Guardar',
  'Terms Box Configuration' => '',
);

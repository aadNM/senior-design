<?php
return array (
  'Back to modules' => 'Takaisin',
  'Save' => 'Tallenna',
  'Terms Box Configuration' => '',
);

<?php
return array (
  'Active' => 'Actiu',
  'Content' => 'Contingut',
  'Hide users which not accepted the terms (Note: May require search index rebuild)' => '',
  'Mark as unseen for all users' => 'Marca com a no llegit per a tots els membres',
  'Please Read and Agree to our Terms & Conditions' => '',
  'Show terms as modal' => '',
  'Statement' => '',
  'Terms & Conditions' => '',
  'Title' => 'Títol',
);

<?php
return array (
  'Accept' => 'Akceptuj',
  'Decline' => 'Odrzuć',
);

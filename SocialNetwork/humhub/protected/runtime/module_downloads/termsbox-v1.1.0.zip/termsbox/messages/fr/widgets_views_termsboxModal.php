<?php
return array (
  'Accept' => 'Accepter',
  'Decline' => 'Refuser',
);

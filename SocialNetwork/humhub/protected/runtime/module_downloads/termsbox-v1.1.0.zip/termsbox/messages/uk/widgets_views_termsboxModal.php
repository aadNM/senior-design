<?php
return array (
  'Accept' => 'Прийміть',
  'Decline' => '',
);

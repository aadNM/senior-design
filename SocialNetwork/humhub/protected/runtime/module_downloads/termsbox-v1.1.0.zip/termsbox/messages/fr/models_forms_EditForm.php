<?php
return array (
  'Active' => 'Actif',
  'Content' => 'Contenu',
  'Hide users which not accepted the terms (Note: May require search index rebuild)' => 'Masquer les utilisateurs qui n\'ont pas accepté les termes (Remarque : peut nécessiter une reconstruction de l\'index de recherche)',
  'Mark as unseen for all users' => 'Marquer comme "non lu" pour tous les utilisateurs',
  'Please Read and Agree to our Terms & Conditions' => 'Veuillez lire et accepter nos conditions générales',
  'Show terms as modal' => 'Afficher les termes comme modèle',
  'Statement' => 'Déclaration',
  'Terms & Conditions' => 'Conditions d\'utilisation',
  'Title' => 'Titre',
);

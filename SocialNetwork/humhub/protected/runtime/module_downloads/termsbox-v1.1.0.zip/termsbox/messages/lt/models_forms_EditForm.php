<?php
return array (
  'Active' => 'Aktyvus',
  'Content' => 'Turinys',
  'Hide users which not accepted the terms (Note: May require search index rebuild)' => '',
  'Mark as unseen for all users' => 'Pažymėti kaip neperskaitytus visiems vartotojams',
  'Please Read and Agree to our Terms & Conditions' => '',
  'Show terms as modal' => '',
  'Statement' => '',
  'Terms & Conditions' => '',
  'Title' => 'Pavadinimas',
);

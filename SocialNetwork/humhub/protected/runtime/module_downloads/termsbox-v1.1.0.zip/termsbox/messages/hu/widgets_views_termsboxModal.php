<?php
return array (
  'Accept' => 'Elfogadás',
  'Decline' => 'Nem vesz részt',
);

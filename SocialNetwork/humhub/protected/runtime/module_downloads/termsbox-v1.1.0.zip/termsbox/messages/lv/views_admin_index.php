<?php
return array (
  'Back to modules' => 'Atpakaļ uz moduļiem',
  'Save' => 'Saglabāt',
  'Terms Box Configuration' => '',
);

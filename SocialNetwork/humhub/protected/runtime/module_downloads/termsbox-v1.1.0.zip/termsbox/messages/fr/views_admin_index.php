<?php
return array (
  'Back to modules' => 'Retour aux modules',
  'Save' => 'Enregistrer',
  'Terms Box Configuration' => 'Configuration de la boîte des conditions d\'utilisation',
);

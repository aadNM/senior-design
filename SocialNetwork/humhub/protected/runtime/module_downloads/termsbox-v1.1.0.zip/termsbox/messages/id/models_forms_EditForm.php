<?php
return array (
  'Active' => 'Aktif',
  'Content' => 'Konten',
  'Hide users which not accepted the terms (Note: May require search index rebuild)' => '',
  'Mark as unseen for all users' => 'Tandai agar tak terlihat untuk semua pengguna',
  'Please Read and Agree to our Terms & Conditions' => '',
  'Show terms as modal' => '',
  'Statement' => '',
  'Terms & Conditions' => '',
  'Title' => 'Judul',
);

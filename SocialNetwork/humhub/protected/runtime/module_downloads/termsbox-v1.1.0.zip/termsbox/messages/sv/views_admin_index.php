<?php
return array (
  'Back to modules' => 'Tillbaka till moduler',
  'Save' => 'Spara',
  'Terms Box Configuration' => 'Konfigurering av villkorsrutan',
);

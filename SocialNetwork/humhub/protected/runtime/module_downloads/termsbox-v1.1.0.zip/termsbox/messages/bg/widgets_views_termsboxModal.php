<?php
return array (
  'Accept' => 'Приемам',
  'Decline' => 'Отказвам',
);

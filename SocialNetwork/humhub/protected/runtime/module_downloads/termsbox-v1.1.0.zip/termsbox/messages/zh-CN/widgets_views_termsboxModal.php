<?php
return array (
  'Accept' => '接受',
  'Decline' => '拒绝',
);

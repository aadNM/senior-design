<?php
return array (
  'Accept' => 'Priimti',
  'Decline' => 'Atmesti',
);

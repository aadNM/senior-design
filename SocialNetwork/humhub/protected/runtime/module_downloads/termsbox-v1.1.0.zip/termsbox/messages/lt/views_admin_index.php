<?php
return array (
  'Back to modules' => 'Atgal į modulius',
  'Save' => 'Išsaugoti',
  'Terms Box Configuration' => '',
);

<?php
return array (
  'Active' => 'Activa',
  'Content' => 'Contenido',
  'Hide users which not accepted the terms (Note: May require search index rebuild)' => 'Esconder usuarios los cuales no han aceptado los términos (Nota: Puede requerir reconstruir el índice)',
  'Mark as unseen for all users' => 'Marcar como no vista para todos los usuarios',
  'Please Read and Agree to our Terms & Conditions' => 'Por favor leer y aceptar nuestros términos y condiciones',
  'Show terms as modal' => 'Mostrar términos como modalidad',
  'Statement' => 'Estatuto',
  'Terms & Conditions' => 'Términos y condiciones',
  'Title' => 'Título',
);

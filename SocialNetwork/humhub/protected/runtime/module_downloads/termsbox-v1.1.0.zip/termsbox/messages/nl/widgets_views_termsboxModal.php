<?php
return array (
  'Accept' => 'Aanvaarden',
  'Decline' => 'Afwijzen',
);

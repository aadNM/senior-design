<?php
return array (
  'Back to modules' => '',
  'Save' => '儲存',
  'Terms Box Configuration' => '',
);

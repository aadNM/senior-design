<?php
return array (
  'Active' => 'Ενεργός',
  'Content' => 'Περιεχόμενο',
  'Hide users which not accepted the terms (Note: May require search index rebuild)' => '',
  'Mark as unseen for all users' => 'Σημειώστε ως αόρατο για όλους τους χρήστες',
  'Please Read and Agree to our Terms & Conditions' => '',
  'Show terms as modal' => '',
  'Statement' => '',
  'Terms & Conditions' => '',
  'Title' => 'Τίτλος',
);

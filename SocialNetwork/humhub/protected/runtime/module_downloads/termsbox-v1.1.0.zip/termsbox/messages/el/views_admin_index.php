<?php
return array (
  'Back to modules' => 'Επιστροφή στις ενότητες',
  'Save' => 'Αποθήκευση',
  'Terms Box Configuration' => '',
);

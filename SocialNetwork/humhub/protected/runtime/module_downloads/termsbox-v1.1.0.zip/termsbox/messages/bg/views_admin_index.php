<?php
return array (
  'Back to modules' => 'Върни се при модулите',
  'Save' => 'Запази',
  'Terms Box Configuration' => 'Конфигурация на полето за условия',
);

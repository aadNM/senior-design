<?php
return array (
  'Accept' => 'Přijmout',
  'Decline' => 'Nechci se zúčastnit',
);

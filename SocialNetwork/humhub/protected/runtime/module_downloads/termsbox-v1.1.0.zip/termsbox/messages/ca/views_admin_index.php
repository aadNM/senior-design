<?php
return array (
  'Back to modules' => 'Torna al mòduls',
  'Save' => 'Desa',
  'Terms Box Configuration' => '',
);

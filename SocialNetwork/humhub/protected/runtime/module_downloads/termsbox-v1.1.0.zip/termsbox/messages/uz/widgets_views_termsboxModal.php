<?php
return array (
  'Accept' => 'Qabul qiling',
  'Decline' => '',
);

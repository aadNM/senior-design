<?php

return [
    'Accept' => '',
    'Decline' => '',
];

<?php
return array (
  'Accept' => '同意',
  'Decline' => '辞退',
);

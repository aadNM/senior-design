<?php
return array (
  'Back to modules' => 'Kembali ke modul',
  'Save' => 'Simpan',
  'Terms Box Configuration' => '',
);

<?php
return array (
  'Active' => 'Aktywny',
  'Content' => 'Zawartość',
  'Hide users which not accepted the terms (Note: May require search index rebuild)' => 'Ukryj użytkowników którzy nie zaakceptowali warunków. (Informacja: Może wymagać przebudowania indeksu)',
  'Mark as unseen for all users' => 'Oznacz jako nieprzeczytane dla wszystkich użytkowników',
  'Please Read and Agree to our Terms & Conditions' => 'Przeczytaj i zaakceptuj nasze warunki i wymagania',
  'Show terms as modal' => 'Pokazuj warunki jako modal',
  'Statement' => 'Oświadczenie',
  'Terms & Conditions' => 'Warunki i Wymagania',
  'Title' => 'Tytuł',
);

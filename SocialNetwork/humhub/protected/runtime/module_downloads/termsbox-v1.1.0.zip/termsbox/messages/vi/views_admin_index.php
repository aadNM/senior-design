<?php
return array (
  'Back to modules' => 'Trở lại Modules',
  'Save' => 'Lưu',
  'Terms Box Configuration' => '',
);

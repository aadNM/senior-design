<?php
return array (
  'Back to modules' => 'Zpět na přehled modulů',
  'Save' => 'Uložit',
  'Terms Box Configuration' => '',
);

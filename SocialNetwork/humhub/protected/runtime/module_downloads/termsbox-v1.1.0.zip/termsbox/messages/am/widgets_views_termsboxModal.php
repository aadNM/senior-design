<?php
return array (
  'Accept' => 'ተቀበል',
  'Decline' => '',
);

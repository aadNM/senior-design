<?php
return array (
  'Back to modules' => '',
  'Save' => 'አስቀምጥ',
  'Terms Box Configuration' => '',
);

<?php
return array (
  'Back to modules' => '',
  'Save' => 'Sere',
  'Terms Box Configuration' => '',
);

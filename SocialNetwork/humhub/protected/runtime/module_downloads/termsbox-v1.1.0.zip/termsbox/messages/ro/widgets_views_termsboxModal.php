<?php
return array (
  'Accept' => 'Accept',
  'Decline' => 'Respinge',
);

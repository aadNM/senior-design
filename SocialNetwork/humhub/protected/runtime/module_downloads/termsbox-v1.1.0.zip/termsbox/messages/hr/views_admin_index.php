<?php
return array (
  'Back to modules' => 'Povratak na module',
  'Save' => 'Spremi',
  'Terms Box Configuration' => '',
);

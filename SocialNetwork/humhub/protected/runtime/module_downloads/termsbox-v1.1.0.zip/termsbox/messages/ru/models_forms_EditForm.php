<?php
return array (
  'Active' => 'Активно',
  'Content' => 'Контент',
  'Hide users which not accepted the terms (Note: May require search index rebuild)' => '',
  'Mark as unseen for all users' => 'Пометить как "Непросмотренное" для всех пользователей',
  'Please Read and Agree to our Terms & Conditions' => '',
  'Show terms as modal' => '',
  'Statement' => '',
  'Terms & Conditions' => '',
  'Title' => 'Заголовок',
);

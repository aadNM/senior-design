<?php
return array (
  'Back to modules' => 'Zurück zu den Modulen',
  'Save' => 'Speichern',
  'Terms Box Configuration' => 'Konfiguration der Bedingungen-Box',
);

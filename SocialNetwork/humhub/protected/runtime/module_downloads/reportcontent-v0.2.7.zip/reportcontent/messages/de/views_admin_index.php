<?php
return array (
  'Here you can manage reported users posts.' => 'Hier kannst Du gemeldete Benutzer-Beiträge verwalten.',
);

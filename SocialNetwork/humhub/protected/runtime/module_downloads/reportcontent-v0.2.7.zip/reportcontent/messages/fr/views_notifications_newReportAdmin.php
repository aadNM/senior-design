<?php
return array (
  '%displayName% has reported %contentTitle% as offensive.' => '%displayName% a rapporté la publication %contentTitle% comme offensive.',
  '%displayName% has reported %contentTitle% as spam.' => '%displayName% a rapporté la publication %contentTitle% comme indésirable.',
  '%displayName% has reported %contentTitle% for not belonging to the space.' => '%displayName% a rapporté la publication %contentTitle% comme inappropriée à cet espace.',
);

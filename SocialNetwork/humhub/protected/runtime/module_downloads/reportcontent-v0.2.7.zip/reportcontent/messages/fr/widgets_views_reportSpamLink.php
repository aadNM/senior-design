<?php
return array (
  'Does not belong here' => 'Ne concerne pas cet espace.',
  'Help Us Understand What\'s Happening' => 'Aidez-nous à comprendre ce qui se passe',
  'It\'s offensive' => 'C\'est choquant',
  'It\'s spam' => 'C\'est indésirable',
  'Report post' => 'Signaler le contenu',
  'Submit' => 'Envoyer',
);

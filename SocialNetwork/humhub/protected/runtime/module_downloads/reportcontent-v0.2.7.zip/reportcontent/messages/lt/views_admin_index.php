<?php
return array (
  'Here you can manage reported users posts.' => 'Čia Jūs galite tvarkyti skelbimus, apie kuriuos pranešė vartotojai.',
);

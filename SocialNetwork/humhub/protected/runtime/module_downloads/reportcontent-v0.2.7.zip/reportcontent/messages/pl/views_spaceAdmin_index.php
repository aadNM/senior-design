<?php
return array (
  'Here you can manage reported posts for this space.' => 'W tym miejscu możesz zarządzać zgłoszonymi treściami dla tej strefy.',
);

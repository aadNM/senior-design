<?php
return array (
  'An user has reported your post as offensive.' => 'Egy felhasználó jelentette a bejegyzésed, mint sértő tartalmat.',
  'An user has reported your post as spam.' => 'Egy felhasználó jelentette a bejegyzésed, mint spamet.',
  'An user has reported your post for not belonging to the space.' => 'Egy felhasználó jelentette a bejegyzésed, mint ami nem tartozik a közösséghez.',
);

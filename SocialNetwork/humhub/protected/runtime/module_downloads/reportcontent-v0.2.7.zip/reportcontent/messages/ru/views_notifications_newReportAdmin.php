<?php
return array (
  '%displayName% has reported %contentTitle% as offensive.' => '%displayName% отметил %contentTitle% как оскорбительный.',
  '%displayName% has reported %contentTitle% as spam.' => '%displayName% отметил %contentTitle% как спам.',
  '%displayName% has reported %contentTitle% for not belonging to the space.' => '%displayName% отметил %contentTitle% несоответствующим данному пространству.',
);

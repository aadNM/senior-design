<?php
return array (
  'Does not belong here' => 'Ne pripada ovdje',
  'Help Us Understand What\'s Happening' => 'Pomozite nam razumjeti što se događa',
  'It\'s offensive' => 'Uvredljivo je',
  'It\'s spam' => 'Spam je',
  'Report post' => 'Prijavi objavu',
  'Submit' => 'Potvrdi',
);

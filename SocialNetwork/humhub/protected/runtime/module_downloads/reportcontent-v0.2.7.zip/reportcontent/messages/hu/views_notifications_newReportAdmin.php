<?php
return array (
  '%displayName% has reported %contentTitle% as offensive.' => '%displayName% jelentette a %contentTitle% , mint sértő tartalmat.',
  '%displayName% has reported %contentTitle% as spam.' => '%displayName% jelentette a %contentTitle% , mint spamet.',
  '%displayName% has reported %contentTitle% for not belonging to the space.' => '%displayName% jelentette a %contentTitle% , mint ami nem tartozik a közösséghez.',
);

<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Erősítsd meg</strong>, hogy törölni akarod a bejegyzést.',
  '<strong>Confirm</strong> report deletion' => '<strong>Erősítsd meg</strong>, hogy törölni akarod a jelentést.',
  'Approve' => 'Elfogadás',
  'Approve post' => 'Bejegyzés elfogadása',
  'Cancel' => 'Mégsem',
  'Content' => 'Tartalom',
  'Delete' => 'Törlés',
  'Delete post' => 'Poszt törlése',
  'Do you really want to approve this post?' => 'Tényleg jóváhagyod ezt a bejegyzést?',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Tényleg törölni akarod ezt a bejegyzést? Minden lájk és hozzászólás törölve lesz!',
  'Reason' => 'Ok',
  'Reporter' => 'Bejelentő',
  'There are no reported posts.' => 'Nincsenek jelentett bejegyzések.',
);

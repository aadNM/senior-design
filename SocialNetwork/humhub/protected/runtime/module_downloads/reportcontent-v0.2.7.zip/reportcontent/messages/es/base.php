<?php
return array (
  'Manage <strong>reported posts</strong>' => 'Administrar <strong>entradas reportadas</strong>',
  'Please provide a reason, why you want to report this content.' => 'Por favor entrega una razón, por qué quieres reportar este contenido.',
  'Reported posts' => 'Entradas reportadas',
  'Why do you want to report this post?' => '¿Por qué quieres reportar este post?',
  'by :displayName' => 'por :displayName',
  'created by :displayName' => 'creado por :displayName',
);

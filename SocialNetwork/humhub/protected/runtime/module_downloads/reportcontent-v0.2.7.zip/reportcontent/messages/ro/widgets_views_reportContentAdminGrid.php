<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Confirmă</strong> ștergerea postării',
  '<strong>Confirm</strong> report deletion' => '',
  'Approve' => '',
  'Approve post' => '',
  'Cancel' => 'Anulează',
  'Content' => 'Conținut',
  'Delete' => 'Șterge',
  'Delete post' => '',
  'Do you really want to approve this post?' => '',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Sigur dorești să ștergi această postare? Toate aprecierile și comentariile vor fi pierdute!',
  'Reason' => '',
  'Reporter' => '',
  'There are no reported posts.' => '',
);

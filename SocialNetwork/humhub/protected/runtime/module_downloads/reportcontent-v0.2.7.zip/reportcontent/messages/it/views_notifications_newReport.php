<?php
return array (
  'An user has reported your post as offensive.' => 'Un utente ha segnalato il tuo post come offensivo. ',
  'An user has reported your post as spam.' => 'Un utente ha segnalato il tuo post come spam. ',
  'An user has reported your post for not belonging to the space.' => 'Un utente ha segnalato il tuo post come non attinente allo spazio. ',
);

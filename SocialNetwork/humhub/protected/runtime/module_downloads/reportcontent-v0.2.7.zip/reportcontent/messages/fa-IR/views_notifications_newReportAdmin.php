<?php
return array (
  '%displayName% has reported %contentTitle% as offensive.' => '%displayName% %contentTitle% را توهین‌آمیز گزارش کرده‌است.',
  '%displayName% has reported %contentTitle% as spam.' => '%displayName% %contentTitle% را اسپم گزارش کرده‌است.',
  '%displayName% has reported %contentTitle% for not belonging to the space.' => '%displayName% گزارش کرده‌است که %contentTitle% متعلق به انجمن نیست.',
);

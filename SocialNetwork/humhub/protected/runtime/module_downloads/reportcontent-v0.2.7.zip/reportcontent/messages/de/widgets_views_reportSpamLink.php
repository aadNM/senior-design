<?php
return array (
  'Does not belong here' => 'Gehört nicht hierher',
  'Help Us Understand What\'s Happening' => 'Hilf uns zu verstehen, was passiert ist',
  'It\'s offensive' => 'Ist beleidigend',
  'It\'s spam' => 'Ist Spam',
  'Report post' => 'Beitrag melden',
  'Submit' => 'Absenden',
);

<?php

return [
    'Here you can manage reported users posts.' => '',
];

<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Potwierdź</strong> usunięcie treści',
  '<strong>Confirm</strong> report deletion' => '<strong>Potwierdź</strong> usunięcie zgłoszenie',
  'Approve' => 'Zatwierdź',
  'Approve post' => 'Zatwierdź post',
  'Cancel' => 'Anuluj',
  'Content' => 'Treść',
  'Delete' => 'Usuń',
  'Delete post' => 'Usuń treść',
  'Do you really want to approve this post?' => 'Na pewno chcesz zatwierdzić ten wpis?',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Czy na pewno usunąć tę treść? Wszystkie komentarze i polubienia zostaną usunięte.',
  'Reason' => 'Powód',
  'Reporter' => 'Zgłaszający',
  'There are no reported posts.' => 'Brak zgłoszonych treści.',
);

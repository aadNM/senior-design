<?php
return array (
  'Doesn\'t belong to space' => 'Nepriklauso erdvei',
  'Offensive' => 'Įžeidžiantis',
  'Spam' => 'Šiukšlės',
);

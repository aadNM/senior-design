<?php
return array (
  'Manage <strong>reported posts</strong>' => 'Gestisci <strong>post segnalati</strong>',
  'Please provide a reason, why you want to report this content.' => 'Dai una ragione del perché segnali un post. ',
  'Reported posts' => 'Post segnalati. ',
  'Why do you want to report this post?' => 'Perché vuoi segnalare un post? ',
  'by :displayName' => 'Da :displayName',
  'created by :displayName' => 'Creato da :displayName',
);

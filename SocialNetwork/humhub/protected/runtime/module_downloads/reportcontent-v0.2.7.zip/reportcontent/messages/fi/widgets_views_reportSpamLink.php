<?php
return array (
  'Does not belong here' => 'Ei kuulu tänne',
  'Help Us Understand What\'s Happening' => 'Auta meitä ymmärtämään, mitä tapahtuu',
  'It\'s offensive' => 'Se on loukkaavaa',
  'It\'s spam' => 'Se on roskapostia',
  'Report post' => 'Ilmoita julkaisu',
  'Submit' => 'Lähetä',
);

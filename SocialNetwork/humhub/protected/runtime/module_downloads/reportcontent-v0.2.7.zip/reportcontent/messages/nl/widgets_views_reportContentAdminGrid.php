<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Bevestig</strong> verwijderen van bericht.',
  '<strong>Confirm</strong> report deletion' => '<strong>Bevestig</strong> verwijderen van rapportage',
  'Approve' => 'Goedkeuren',
  'Approve post' => 'Keur bericht goed',
  'Cancel' => 'Annuleren',
  'Content' => 'Content',
  'Delete' => 'Verwijderen',
  'Delete post' => 'Verwijder bericht',
  'Do you really want to approve this post?' => 'Wilt u dit bericht goedkeuren?',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Wil je dit bericht echt verwijderen? Alle likes en commentaren gaan ook verloren!',
  'Reason' => 'Reden',
  'Reporter' => 'Rapporteerder',
  'There are no reported posts.' => 'Er zijn geen gerapporteerde berichten.',
);

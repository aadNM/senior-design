<?php
return array (
  '%displayName% has reported %contentTitle% as offensive.' => '%displayName% pranešė %contentTitle% kaip įžeidimą.',
  '%displayName% has reported %contentTitle% as spam.' => '%displayName% pranešė %contentTitle% kaip šiukšlę.',
  '%displayName% has reported %contentTitle% for not belonging to the space.' => '%displayName% pranešė %contentTitle% kaip nepriklausantį erdvei.',
);

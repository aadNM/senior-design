<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Potvrdi</strong> brisanje objave',
  '<strong>Confirm</strong> report deletion' => '<strong>Potvrdi</strong> brisanje objave',
  'Approve' => 'Odobri',
  'Approve post' => 'Odobri objavu',
  'Cancel' => 'Poništi',
  'Content' => 'Sadržaj',
  'Delete' => 'Obriši',
  'Delete post' => 'Obriši objavu',
  'Do you really want to approve this post?' => 'Zaista želite odobriti ovu objavu?',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Zaista želite obrisati ovu objavu? Svi \'\'like-ovi\'\' i komnetari biti će obrisani!',
  'Reason' => 'Razlog',
  'Reporter' => 'Prijavitelj',
  'There are no reported posts.' => 'Nema prijavljenih objava.',
);

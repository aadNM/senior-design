<?php
return array (
  '%displayName% has reported %contentTitle% as offensive.' => '%displayName% prijavio je %contentTitle% kao uvredljiv.',
  '%displayName% has reported %contentTitle% as spam.' => '%displayName% prijavio je %contentTitle% kao spam.',
  '%displayName% has reported %contentTitle% for not belonging to the space.' => '%displayName% prijavio je %contentTitle% zato jer ne pripada u prostor.',
);

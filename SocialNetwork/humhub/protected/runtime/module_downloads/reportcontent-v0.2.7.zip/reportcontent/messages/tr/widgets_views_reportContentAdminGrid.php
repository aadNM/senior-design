<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Mesaj</strong> silmeyi onayla',
  '<strong>Confirm</strong> report deletion' => '<strong>Rapor</strong> silmeyi onayla',
  'Approve' => 'Onayla',
  'Approve post' => 'Gönderiyi onayla',
  'Cancel' => 'İptal',
  'Content' => 'İçerik',
  'Delete' => 'Sil',
  'Delete post' => 'Mesajı sil',
  'Do you really want to approve this post?' => 'Bu gönderiyi gerçekten onaylamak istiyor musunuz?',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Bu yazıyı silmek istiyor musunuz? Yorumlar ve beğeniler silinecektir!',
  'Reason' => 'Neden',
  'Reporter' => 'Tarafından',
  'There are no reported posts.' => 'Rapor edilen gönderi bulunamadı.',
);

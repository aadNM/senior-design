<?php

return [
    'Here you can manage reported posts for this space.' => '',
];

<?php
return array (
  'An user has reported your post as offensive.' => 'Có người đã tố cáo bài post của bạn là PHẢN CẢM.',
  'An user has reported your post as spam.' => 'Có người đã tố cáo bài post của bạn là SPAM',
  'An user has reported your post for not belonging to the space.' => 'Có người đã tố cáo bài post của bạn không thích hợp thuộc về diễn đàn.',
);

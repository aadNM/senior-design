<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>确认</strong> 删除记录',
  '<strong>Confirm</strong> report deletion' => '',
  'Approve' => '',
  'Approve post' => '',
  'Cancel' => '取消',
  'Content' => '内容',
  'Delete' => '删除',
  'Delete post' => '',
  'Do you really want to approve this post?' => '',
  'Do you really want to delete this post? All likes and comments will be lost!' => '你真的想删除该记录？喜欢和评论内容都将丢失！',
  'Reason' => '',
  'Reporter' => '',
  'There are no reported posts.' => '',
);

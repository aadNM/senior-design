<?php
return array (
  'An user has reported your post as offensive.' => 'En bruger har anmeldt dit opslag som angribende.',
  'An user has reported your post as spam.' => 'En bruger har anmeldt dit opslag som spam.',
  'An user has reported your post for not belonging to the space.' => 'En bruger har anmeldt dit opslag fordi det ikke hører til på siden.',
);

<?php
return array (
  'Doesn\'t belong to space' => 'Non é attinente allo spazio. ',
  'Offensive' => 'Offensivo',
  'Spam' => 'Spam',
);

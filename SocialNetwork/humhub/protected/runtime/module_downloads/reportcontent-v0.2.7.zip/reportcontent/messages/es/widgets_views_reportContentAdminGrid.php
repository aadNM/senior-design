<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Confirma</strong> el borrado de la entrada',
  '<strong>Confirm</strong> report deletion' => '<strong>Confirmar</strong> reporte de eliminación',
  'Approve' => 'Aprobar',
  'Approve post' => 'Aprobar post',
  'Cancel' => 'Cancelar',
  'Content' => 'Contenido',
  'Delete' => 'Borrar',
  'Delete post' => 'Eliminar entrada',
  'Do you really want to approve this post?' => '¿De verdad quieres aprobar este post?',
  'Do you really want to delete this post? All likes and comments will be lost!' => '¿Realmente deseas borrar esta entrada? ¡Todos los "Me gusta" y los comentarios se perderán!',
  'Reason' => 'Razón',
  'Reporter' => 'Reportador',
  'There are no reported posts.' => 'No hay posts reportados.',
);

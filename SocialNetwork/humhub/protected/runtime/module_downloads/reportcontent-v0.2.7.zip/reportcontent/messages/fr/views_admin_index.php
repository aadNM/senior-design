<?php
return array (
  'Here you can manage reported users posts.' => 'Vous pouvez gérer ici les contenus signalés par les utilisateurs.',
);

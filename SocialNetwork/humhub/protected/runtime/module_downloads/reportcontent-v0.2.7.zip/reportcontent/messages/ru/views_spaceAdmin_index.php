<?php
return array (
  'Here you can manage reported posts for this space.' => 'Здесь вы можете управлять репортами для данного пространства.',
);

<?php
return array (
  'Doesn\'t belong to space' => 'Nem tartozik a közösséghez',
  'Offensive' => 'Sértő',
  'Spam' => 'Spam',
);

<?php
return array (
  '%displayName% has reported %contentTitle% as offensive.' => '%displayName% ha segnalato %contentTitle% come offensivo. ',
  '%displayName% has reported %contentTitle% as spam.' => '%displayName% ha segnalato %contentTitle% come spam. ',
  '%displayName% has reported %contentTitle% for not belonging to the space.' => '%displayName% ha segnalato %contentTitle% come non attinente allo spazio. ',
);

<?php
return array (
  'Does not belong here' => 'Не принадлежит к этому пространству',
  'Help Us Understand What\'s Happening' => 'Помогите нам понять, что происходит',
  'It\'s offensive' => 'Это нарушение',
  'It\'s spam' => 'Это спам',
  'Report post' => 'Жалоба на сообщение',
  'Submit' => 'Принять',
);

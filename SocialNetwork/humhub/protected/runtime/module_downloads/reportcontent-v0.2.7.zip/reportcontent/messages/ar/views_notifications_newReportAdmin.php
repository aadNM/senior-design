<?php
return array (
  '%displayName% has reported %contentTitle% as offensive.' => '',
  '%displayName% has reported %contentTitle% as spam.' => '',
  '%displayName% has reported %contentTitle% for not belonging to the space.' => '',
);

<?php
return array (
  'Does not belong here' => 'To nie należy do tej strefy',
  'Help Us Understand What\'s Happening' => 'Pomóż nam zrozumieć co się dzieje',
  'It\'s offensive' => 'To jest obraźliwe',
  'It\'s spam' => 'To jest spam',
  'Report post' => 'Zgłoś treść',
  'Submit' => 'Wyślij',
);

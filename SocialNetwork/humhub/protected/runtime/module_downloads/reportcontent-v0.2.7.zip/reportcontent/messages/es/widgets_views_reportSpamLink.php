<?php
return array (
  'Does not belong here' => 'No pertenece aquí',
  'Help Us Understand What\'s Happening' => 'Ayúdanos a entender qué sucede',
  'It\'s offensive' => 'Es ofensivo',
  'It\'s spam' => 'Es spam',
  'Report post' => 'Reportar post',
  'Submit' => 'Enviar',
);

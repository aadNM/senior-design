<?php
return array (
  'Doesn\'t belong to space' => 'Ne pripada prostoru',
  'Offensive' => 'Uvredljivo',
  'Spam' => 'Spam',
);

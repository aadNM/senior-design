<?php
return array (
  '<strong>Confirm</strong> post deletion' => 'ልጥፉ እንዲወገድ <strong>አረጋግጥ</strong>',
  '<strong>Confirm</strong> report deletion' => '',
  'Approve' => '',
  'Approve post' => '',
  'Cancel' => 'ይቅር',
  'Content' => 'ይዘት',
  'Delete' => 'አስወግድ',
  'Delete post' => '',
  'Do you really want to approve this post?' => '',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'ይህን ልጥፍ ለማስወገድ መፈለግዎን እርግጠኛ ኖት? ሁሉም ተወዳጆች እና አስተያየቶች ይጠፋሉ!',
  'Reason' => '',
  'Reporter' => '',
  'There are no reported posts.' => '',
);

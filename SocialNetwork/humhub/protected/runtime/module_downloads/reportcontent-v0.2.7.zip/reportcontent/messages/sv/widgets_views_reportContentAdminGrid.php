<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Bekräfta</strong> radering av post',
  '<strong>Confirm</strong> report deletion' => '',
  'Approve' => '',
  'Approve post' => '',
  'Cancel' => 'Avbryt',
  'Content' => 'Innehåll',
  'Delete' => 'Ta bort',
  'Delete post' => '',
  'Do you really want to approve this post?' => '',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Vill du verkligen radera? Alla kommentarer tas bort!',
  'Reason' => '',
  'Reporter' => '',
  'There are no reported posts.' => '',
);

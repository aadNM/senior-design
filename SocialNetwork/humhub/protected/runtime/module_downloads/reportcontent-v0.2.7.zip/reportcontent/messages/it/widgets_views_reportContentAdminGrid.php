<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Conferma</strong> la cancellazione dell\'articolo',
  '<strong>Confirm</strong> report deletion' => '<strong>Conferma</strong> la cancellazione della segnalazione',
  'Approve' => 'Approva',
  'Approve post' => 'Approva post',
  'Cancel' => 'Annulla',
  'Content' => 'Contenuti',
  'Delete' => 'Cancella',
  'Delete post' => 'Cancella post',
  'Do you really want to approve this post?' => 'Vuoi approvare questo post? ',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Vuoi veramente cancellare questo post? Tutti i commenti e i like andranno persi!',
  'Reason' => 'Motivo',
  'Reporter' => 'Segnalatore',
  'There are no reported posts.' => 'Non ci sono post segnalati',
);

<?php
return array (
  '<strong>Confirm</strong> post deletion' => '投稿の削除を決行する',
  '<strong>Confirm</strong> report deletion' => '',
  'Approve' => '',
  'Approve post' => '',
  'Cancel' => 'キャンセル',
  'Content' => 'コンテンツ',
  'Delete' => '削除',
  'Delete post' => '',
  'Do you really want to approve this post?' => '',
  'Do you really want to delete this post? All likes and comments will be lost!' => '本当に削除してもよろしいですか？いいね！やコメントも一緒に消えてしまいます。',
  'Reason' => '',
  'Reporter' => '',
  'There are no reported posts.' => '',
);

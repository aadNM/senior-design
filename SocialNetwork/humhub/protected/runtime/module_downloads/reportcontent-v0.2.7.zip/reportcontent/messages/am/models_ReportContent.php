<?php

return [
    'Doesn\'t belong to space' => '',
    'Offensive' => '',
    'Spam' => '',
];

<?php
return array (
  'An user has reported your post as offensive.' => 'Un utilisateur a rapporté votre publication comme offensive.',
  'An user has reported your post as spam.' => 'Un utilisateur a rapporté votre publication comme indésirable.',
  'An user has reported your post for not belonging to the space.' => 'Un utilisateur a rapporté votre publication comme inappropriée à cet espace.',
);

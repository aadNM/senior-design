<?php
return array (
  'Does not belong here' => 'Não pertence a este espaço',
  'Help Us Understand What\'s Happening' => 'Ajude-nos a entender o que está acontecendo',
  'It\'s offensive' => 'É ofensivo',
  'It\'s spam' => 'É SPAM',
  'Report post' => 'Denunciar postagem',
  'Submit' => 'Enviar',
);

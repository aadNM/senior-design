<?php
return array (
  'Manage <strong>reported posts</strong>' => '<strong>Jelentett bejegyzések</strong>kezelése',
  'Please provide a reason, why you want to report this content.' => 'Kérjük, indokold meg, miért akarod jelenteni ezt a tartalmat.',
  'Reported posts' => 'Jelentett bejegyzések',
  'Why do you want to report this post?' => 'Miért akarod jelenteni ezt a bejegyzést?',
  'by :displayName' => ':displayName által',
  'created by :displayName' => ':displayName által létrehozva',
);

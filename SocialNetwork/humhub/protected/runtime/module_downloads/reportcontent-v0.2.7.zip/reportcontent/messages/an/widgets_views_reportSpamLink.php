<?php
return array (
  'Does not belong here' => '',
  'Help Us Understand What\'s Happening' => '',
  'It\'s offensive' => '',
  'It\'s spam' => '',
  'Report post' => '',
  'Submit' => 'Ninviar',
);

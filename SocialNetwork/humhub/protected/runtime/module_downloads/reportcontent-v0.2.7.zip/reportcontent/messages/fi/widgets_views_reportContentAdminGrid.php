<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Vahvista</strong> julkaisun poistaminen',
  '<strong>Confirm</strong> report deletion' => '<strong>Vahvista</strong> ilmoituksen poistaminen',
  'Approve' => 'Hyväksy',
  'Approve post' => 'Hyväksy julkaisu',
  'Cancel' => 'Peruuta',
  'Content' => 'Sisältö',
  'Delete' => 'Poista',
  'Delete post' => 'Poista viesti',
  'Do you really want to approve this post?' => 'Haluatko todella hyväksyä tämän viestin?',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Haluatko todella poistaa tämän julkaisun? Kaikki tykkäykset ja kommentit menetetään!',
  'Reason' => 'Syy',
  'Reporter' => 'Ilmoittaja',
  'There are no reported posts.' => 'Ilmoitettuja julkaisuja ei tällä hetkellä ole.',
);

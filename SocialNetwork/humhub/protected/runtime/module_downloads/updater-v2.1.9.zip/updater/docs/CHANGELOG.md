Changelog
=========

2.1.9  (February 5, 2021)
--------------------------
- Fix: Better handle errors when assets directory cannot be cleared (+ retry)


2.1.8  (November 6, 2020)
--------------------------
- Fix: Clear assets directory at the end of installation


2.1.7  (April 22, 2020)
--------------------------
- Fix: 1.3 compatibility support 


2.1.6  (April 21, 2020)
--------------------------
- Fix: Missing import in start view (@ArchBlood)
 
 
2.1.5  (April 21, 2020)
--------------------------
- Enh: Added cleanup backup job
 

2.1.4  (April 16, 2020)
--------------------------
- Fix: Self updater update check broken
 

2.1.3  (April 14, 2020)
--------------------------
- Enh: Allow complete humhub directory replace
- Enh: Updated translation


2.1.2  (December 11, 2019)
--------------------------
- Enh: Improved HumHub 1.4+ compatibility


2.1.1  (December 10, 2018)
--------------------------
- Enh: Improved theme caching for HumHub 1.3.7+


2.1.0  (July 4, 2018)
---------------------
- Enh: Allow to specify update channel


2.0.8  (July 2, 2018)
---------------------
- Fix: PHP 7.2 compatibility issues

<?php
return array (
  'Update download failed! (%error%)' => 'A frissítés letöltése sikertelen! (%error%)',
);

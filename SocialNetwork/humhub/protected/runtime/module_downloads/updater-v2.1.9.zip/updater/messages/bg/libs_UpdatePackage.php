<?php
return array (
  'Update download failed! (%error%)' => 'Изтеглянето на актуализацията не бе успешно! (%error%)',
);

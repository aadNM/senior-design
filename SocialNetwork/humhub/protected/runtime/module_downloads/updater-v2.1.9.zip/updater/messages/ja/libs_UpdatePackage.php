<?php
return array (
  'Update download failed! (%error%)' => 'アップデートのダウンロードに失敗しました！ （％error％）',
);

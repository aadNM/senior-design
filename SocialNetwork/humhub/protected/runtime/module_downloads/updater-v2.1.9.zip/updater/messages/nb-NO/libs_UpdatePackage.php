<?php
return array (
  'Update download failed! (%error%)' => 'Nedlasting av oppdateringen mislyktes (%error%)',
);

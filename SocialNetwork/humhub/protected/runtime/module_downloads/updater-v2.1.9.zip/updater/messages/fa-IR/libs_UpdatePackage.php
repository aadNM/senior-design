<?php
return array (
  'Update download failed! (%error%)' => 'مشكلي پيش آمد و دانلود بروزرسان انجام نشد....كد ارور(%error%) ',
);

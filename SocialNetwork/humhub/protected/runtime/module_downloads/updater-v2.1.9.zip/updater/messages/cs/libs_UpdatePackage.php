<?php
return array (
  'Update download failed! (%error%)' => 'Aktualizace stahování se nezdařila! (%error%)',
);

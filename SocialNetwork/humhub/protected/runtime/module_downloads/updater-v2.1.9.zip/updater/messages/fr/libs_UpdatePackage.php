<?php
return array (
  'Update download failed! (%error%)' => 'Le téléchargement de la mise à jour a échoué (%error%)',
);

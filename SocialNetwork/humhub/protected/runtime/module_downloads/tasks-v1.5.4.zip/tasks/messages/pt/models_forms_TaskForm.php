<?php
return array (
  'End Date' => 'Data final',
  'End Time' => 'Hora de fim',
  'End time must be after start time!' => 'Horário de fim tem que ser depois da hora de início.',
  'Public' => 'Público',
  'Start Date' => 'Data inicial',
  'Start Time' => 'Hora de início',
  'Time Zone' => 'Fuso Horário',
);

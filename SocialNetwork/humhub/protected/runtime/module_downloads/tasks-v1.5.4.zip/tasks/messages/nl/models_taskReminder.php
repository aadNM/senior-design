<?php
return array (
  '1 Day before' => '1 dag ervoor',
  '1 Month before' => '1 maand ervoor',
  '1 Week before' => '1 week ervoor',
  '2 Days before' => '2 dagen ervoor',
  '2 Weeks before' => '2 weken ervoor',
  '3 Weeks before' => '3 weken ervoor',
  'At least 1 Hour before' => 'Ten minste 1 uur ervoor',
  'At least 2 Hours before' => 'Ten minste 2 uur ervoor',
  'Do not remind' => 'Niet herinneren',
  'Remind Mode' => 'Herinneringsmodus',
  'Task' => 'Taak',
);

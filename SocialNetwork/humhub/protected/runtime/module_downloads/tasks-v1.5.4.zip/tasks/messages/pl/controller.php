<?php
return array (
  'Already requested' => 'Wysłano już zapytanie',
  'Request sent' => 'Zapytanie wysłane',
  'You have insufficient permissions to perform that operation!' => 'Nie jesteś uprawniony/a aby wykonać te operację!',
);

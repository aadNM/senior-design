<?php
return array (
  '<strong>Create</strong> new task' => '<strong>Maak</strong> nieuwe taak',
  '<strong>Edit</strong> task' => '<strong>Bewerk</strong> taak',
  'Assign users' => 'Gebruikers koppelen',
  'Cancel' => 'Annuleren',
  'Deadline' => 'Uiterste datum',
  'Save' => 'Opslaan',
  'What is to do?' => 'Wat is er te doen?',
);

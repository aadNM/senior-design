<?php
return array (
  'Drag list' => 'Arrastar lista',
);

<?php
return array (
  'Task Users have been notified' => 'As pessoas desta tarefa foram notificadas',
);

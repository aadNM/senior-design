<?php
return array (
  '{userName} completed task {task}.' => '{userName} completou a tarefa {task}.',
  '{userName} reset task {task}.' => '{userName} redefiniu a tarefa {task}.',
  '{userName} reviewed task {task}.' => '{userName} reviu a tarefa {task}.',
  '{userName} works on task {task}.' => '{userName} está a trabalhar na tarefa {task}.',
);

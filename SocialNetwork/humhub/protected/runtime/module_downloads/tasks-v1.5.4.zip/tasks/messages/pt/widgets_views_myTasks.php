<?php
return array (
  '<strong>Your</strong> tasks' => '<strong>As tuas</strong> tarefas',
);

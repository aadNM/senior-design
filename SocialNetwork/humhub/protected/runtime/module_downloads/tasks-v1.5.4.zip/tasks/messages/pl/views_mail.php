<?php
return array (
  'Your Reminder for task {task}' => 'Twoje przypomnienie o zadaniu {task}',
);

<?php
return array (
  '{userName} created a new task {task}.' => '{userName} lagde en ny oppgave {task}.
',
);

<?php

return [
    'Already requested' => '',
    'Request sent' => '',
    'You have insufficient permissions to perform that operation!' => '',
];

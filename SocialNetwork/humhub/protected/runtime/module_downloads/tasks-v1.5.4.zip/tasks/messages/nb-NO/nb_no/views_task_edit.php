<?php
return array (
  '<strong>Create</strong> new task' => '<strong>Lag</strong> ny oppgave',
  '<strong>Edit</strong> task' => '<strong>Rediger</strong> oppgave',
  'Assign users' => 'Tilknytt brukere',
  'Cancel' => 'Avbryt',
  'Deadline' => 'Frist',
  'Save' => 'Lagre',
  'What is to do?' => 'Hva er det og gjøre?',
);

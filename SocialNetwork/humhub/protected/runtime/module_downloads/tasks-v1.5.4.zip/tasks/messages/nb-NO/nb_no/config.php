<?php
return array (
  '<strong>Task</strong> module configuration' => '<strong>Oppgave</strong> modul konfigurasjon',
  'Max tasks items' => 'Maksimum oppgave elementer',
  'Show snippet' => 'Vis utdrag',
  'Show snippet in Space' => 'Vis utdrag i gruppen',
  'Shows a widget with tasks on the dashboard where you are assigned/responsible.' => 'Viser en widget med oppgaver på dashbordet hvor du er tildelt / ansvarlig.',
  'Shows the widget also on the dashboard of spaces.' => 'Viser widgeten også på dashbordet i gruppen',
  'Sort order' => 'Sorteringsrekkefølge',
  'Your tasks snippet' => 'Dine oppgave utdrag',
);

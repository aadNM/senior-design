<?php
return array (
  '1 Day before' => '1 Dia antes',
  '1 Month before' => '1 Mês antes',
  '1 Week before' => '1 Semana antes',
  '2 Days before' => '2 Dias antes',
  '2 Weeks before' => '2 Semanas antes',
  '3 Weeks before' => '3 Semanas antes',
  'At least 1 Hour before' => 'Pelo menos 1 Hora antes',
  'At least 2 Hours before' => 'Pelo menos 2 Hora antes',
  'Do not remind' => 'Não lembrar',
  'Remind Mode' => 'Modo de lembrete',
  'Task' => 'Tarefa',
);

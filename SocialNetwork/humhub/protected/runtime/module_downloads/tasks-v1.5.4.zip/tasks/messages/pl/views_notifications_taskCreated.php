<?php
return array (
  '{userName} created a new task {task}.' => '{userName} utworzył nowe zadanie {task}.',
);

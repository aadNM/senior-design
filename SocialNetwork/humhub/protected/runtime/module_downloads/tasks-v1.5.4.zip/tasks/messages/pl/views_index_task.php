<?php
return array (
  'Task Users have been notified' => 'Użytkownicy zostali powiadomieni',
);

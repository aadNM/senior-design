<?php
return array (
  '<strong>Create</strong> new task' => '',
  '<strong>Edit</strong> task' => '',
  'Assign users' => '',
  'Cancel' => 'Batal',
  'Deadline' => '',
  'Save' => 'Simpan',
  'What is to do?' => '',
);

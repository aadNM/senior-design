<?php
return array (
  '<strong>Your</strong> tasks' => '<strong>Tehtävät</strong>',
);

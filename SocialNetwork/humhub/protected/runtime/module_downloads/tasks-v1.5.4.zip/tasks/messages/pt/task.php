<?php
return array (
  'Allows the user to create, delete and edit tasks and lists and also sort tasks and lists' => 'Permite criar, apagar e editar tarefas e listas e também ordenar tarefas e listas',
  'Allows the user to process unassigned tasks' => 'Permite processar tarefas sem atribuição',
  'Manage tasks' => 'Gerir tarefas',
  'Process unassigned tasks' => 'Processar tarefas sem atribuição',
);

<?php
return array (
  'Already requested' => '',
  'Request sent' => '',
  'You have insufficient permissions to perform that operation!' => 'Anda tidak memiliki izin yang memadai untuk melakukan operasi itu!',
);

<?php
return array (
  'Created by me' => 'Stworzone przeze mnie',
  'End date' => 'Data zakończenia',
  'Filter status' => 'stan filtrów',
  'Filter tasks' => 'Filtruj zadania',
  'I\'m assigned' => 'Jestem przypisany/a',
  'I\'m responsible' => 'Jestem odpowiedzialny/a',
  'Overdue' => 'Zaległe',
  'Spaces' => 'Strefy',
  'Start date' => 'Data rozpoczęcia',
  'Status' => 'Status',
  'Title' => 'Tytuł',
);

<?php
return array (
  '{userName} completed task {task}.' => '{userName} voltooide taak {task}.',
  '{userName} reset task {task}.' => '{userName} stelde taak {task} opnieuw in..',
  '{userName} reviewed task {task}.' => '{userName} beoordeelde taak {task}.',
  '{userName} works on task {task}.' => '{userName} werkt aan taak {task}.',
);

<?php
return array (
  'Already requested' => 'Allerede forespurt',
  'Request sent' => 'Forespørsel sendt',
  'You have insufficient permissions to perform that operation!' => 'Du har ikke tilgang til å utføre handlingen!',
);

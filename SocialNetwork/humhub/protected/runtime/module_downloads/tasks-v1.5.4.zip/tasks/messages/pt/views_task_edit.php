<?php
return array (
  '<strong>Create</strong> new task' => '<strong>Criar</strong> nova tarefa',
  '<strong>Edit</strong> task' => '<strong>Editar</strong> tarefa',
  'Assign users' => 'Atribuir pessoas',
  'Cancel' => 'Cancelar',
  'Deadline' => 'Prazo',
  'Save' => 'Gravar',
  'What is to do?' => 'O que é para fazer?',
);

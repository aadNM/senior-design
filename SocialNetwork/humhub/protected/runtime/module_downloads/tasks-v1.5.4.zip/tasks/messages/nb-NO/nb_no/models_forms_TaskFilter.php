<?php
return array (
  'Created by me' => 'Laget av meg',
  'End date' => '',
  'Filter status' => '',
  'Filter tasks' => '',
  'I\'m assigned' => '',
  'I\'m responsible' => '',
  'Overdue' => 'På overtid',
  'Spaces' => 'Grupper',
  'Start date' => '',
  'Status' => 'Status',
  'Title' => 'Tittel',
);

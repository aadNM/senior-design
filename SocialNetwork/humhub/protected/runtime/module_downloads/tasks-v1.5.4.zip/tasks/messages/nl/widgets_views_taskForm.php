<?php
return array (
  'Assign users to this task' => 'Koppel gebruikers aan deze taak',
  'Deadline for this task?' => 'Uiterste datum voor deze taak?',
  'Preassign user(s) for this task.' => 'Wijs vooraf gebruiker(s) toe aan deze taak.',
  'What to do?' => 'Wat is er te doen?',
);

<?php
return array (
  'End Date' => 'Slutter dato',
  'End Time' => 'Slutt',
  'End time must be after start time!' => 'Aktiviteten kan ikke slutte før den har startet!',
  'Public' => 'Offentlig',
  'Start Date' => 'Starter dato',
  'Start Time' => 'Start',
  'Time Zone' => 'Tidssone',
);

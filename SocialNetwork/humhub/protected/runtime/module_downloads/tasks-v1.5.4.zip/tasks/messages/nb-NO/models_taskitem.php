<?php
return array (
  'Completed' => 'Ferdig',
  'Title' => 'Tittel',
);

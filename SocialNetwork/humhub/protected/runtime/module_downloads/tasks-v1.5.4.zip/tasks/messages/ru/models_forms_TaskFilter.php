<?php
return array (
  'Created by me' => 'Создано мной',
  'End date' => '',
  'Filter status' => '',
  'Filter tasks' => '',
  'I\'m assigned' => '',
  'I\'m responsible' => '',
  'Overdue' => '',
  'Spaces' => 'Пространств',
  'Start date' => '',
  'Status' => 'Статус',
  'Title' => 'Заголовок',
);

<?php
return array (
  'Allows the user to create, delete and edit tasks and lists and also sort tasks and lists' => 'Pozwól użytkownikowi tworzyć, usuwać, edytować oraz sortować zadania i listy zadań.',
  'Allows the user to process unassigned tasks' => 'Pozwól użytkownikowi wykonywać nieprzypisane zadania.',
  'Manage tasks' => 'Zarządzanie zadaniami',
  'Process unassigned tasks' => 'Wykonywanie nieprzypisanych zadań',
);

<?php
return array (
  'Your Reminder for task {task}' => 'Din påminnelse for oppgaven {task}',
);

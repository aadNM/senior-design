<?php
return array (
  '{userName} assigned you to the task {task}.' => '{userName} atribuiu-te a tarefa {task}.',
);

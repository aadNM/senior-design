<?php
return array (
  'Drag list' => 'Dra liste',
);

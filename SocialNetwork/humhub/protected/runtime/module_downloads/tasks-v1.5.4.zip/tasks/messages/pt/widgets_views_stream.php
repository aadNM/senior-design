<?php
return array (
  '<b>There are no tasks yet!</b>' => '<b>Ainda não há tarefas!</b>',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>Ainda não há tarefas!</b><br>Sê o primeiro e cria uma...',
  'Assigned to me' => 'Atribuído a mim',
  'Back to stream' => 'Voltar ao stream',
  'Created by me' => 'Criado por mim',
  'Creation time' => 'Hora de criação',
  'Filter' => 'Filtro',
  'Last update' => 'Última atualização',
  'No tasks found which matches your current filter(s)!' => 'Não foram encontradas tarefas que condigam com os teus filtros!',
  'Nobody assigned' => 'Ninguém atribuído',
  'Sorting' => 'Ordenar',
  'State is finished' => 'Estado está completo',
  'State is open' => 'Estado está aberto',
);

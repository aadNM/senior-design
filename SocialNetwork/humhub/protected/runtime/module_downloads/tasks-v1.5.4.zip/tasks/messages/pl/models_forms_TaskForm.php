<?php
return array (
  'End Date' => 'Data zakończenia',
  'End Time' => 'Czas zakończenia',
  'End time must be after start time!' => 'Zacz zakończenia musi być po czasie rozpoczęcia!',
  'Public' => 'Publiczne',
  'Start Date' => 'Data rozpoczęcia',
  'Start Time' => 'Czas rozpoczęcia',
  'Time Zone' => 'Strefa czasowa',
);

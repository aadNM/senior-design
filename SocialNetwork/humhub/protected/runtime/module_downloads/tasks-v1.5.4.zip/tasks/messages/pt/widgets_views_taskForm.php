<?php
return array (
  'Assign users to this task' => 'Atribuir pessoas a esta tarefa',
  'Deadline for this task?' => 'Prazo para esta tarefa?',
  'Preassign user(s) for this task.' => 'Pré-atribuir pessoa(s) a esta tarefa.',
  'What to do?' => 'O que fazer?',
);

<?php
return array (
  '{userName} created task {task}.' => '{userName} создал задачу {task}.',
);

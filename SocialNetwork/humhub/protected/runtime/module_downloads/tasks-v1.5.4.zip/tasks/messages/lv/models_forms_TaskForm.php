<?php
return array (
  'End Date' => 'Beigu datums',
  'End Time' => 'Beigu laiks',
  'End time must be after start time!' => 'Beigu laikam ir jābūt pēc sākuma laika!',
  'Public' => 'Publiska',
  'Start Date' => 'Sākuma datums',
  'Start Time' => 'Sākuma laiks',
  'Time Zone' => '',
);

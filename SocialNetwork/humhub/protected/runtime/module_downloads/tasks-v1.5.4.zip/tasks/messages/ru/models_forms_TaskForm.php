<?php
return array (
  'End Date' => 'Дата окончания',
  'End Time' => 'Время окончания',
  'End time must be after start time!' => 'Время окончания должно быть позже начала',
  'Public' => 'Публичное',
  'Start Date' => 'Дата начала',
  'Start Time' => 'Время начала',
  'Time Zone' => 'Часовой пояс',
);

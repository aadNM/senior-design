<?php
return array (
  'End Date' => 'Tanggal berakhir',
  'End Time' => 'Waktu berakhir',
  'End time must be after start time!' => 'waktu akhir harus setelah waktu mulai !!',
  'Public' => 'Publik',
  'Start Date' => 'Tanggal dimulai',
  'Start Time' => 'Waktu dimulai',
  'Time Zone' => 'Zona Waktu',
);

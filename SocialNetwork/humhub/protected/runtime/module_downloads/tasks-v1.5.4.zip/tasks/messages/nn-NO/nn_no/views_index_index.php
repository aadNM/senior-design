<?php

return [
    'Any user with a "Process unassigned tasks" permission can work on this task' => '',
    'Assigned' => '',
    'Completed' => '',
    'Deadline at' => '',
    'Drag entry' => '',
    'Edit' => '',
    'Filter tasks by title' => '',
    'In Progress' => '',
    'In Review' => '',
    'No Scheduling set for this Task' => '',
    'Overdue' => '',
    'Pending' => '',
    'Pending Review' => '',
    'Reset Task' => '',
    'Responsible' => '',
    'Start now, by creating a new task!' => '',
    'There are currently no upcoming tasks!.' => '',
    'Today' => '',
    'ending Review' => '',
    '{count,plural,=1{# day} other{# days}} remaining' => '',
];

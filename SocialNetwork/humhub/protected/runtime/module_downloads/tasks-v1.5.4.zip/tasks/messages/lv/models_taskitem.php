<?php
return array (
  'Completed' => '',
  'Title' => 'Nosaukums',
);

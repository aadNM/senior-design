<?php
return array (
  '{userName} assigned you as responsible person in task {task} from space {spaceName}.' => '{userName} tildelte deg som ansvarlig for oppgaven {task} for gruppen {spaceName}.',
);

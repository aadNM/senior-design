<?php
return array (
  'Created by me' => 'Criado por mim',
  'End date' => 'Data de fim',
  'Filter status' => 'Filtrar estado',
  'Filter tasks' => 'Filtrar tarefas',
  'I\'m assigned' => 'Tenho atribuição',
  'I\'m responsible' => 'Sou responsável',
  'Overdue' => 'Em atraso',
  'Spaces' => 'Espaços',
  'Start date' => 'Data de início',
  'Status' => 'Estado',
  'Title' => 'Título',
);

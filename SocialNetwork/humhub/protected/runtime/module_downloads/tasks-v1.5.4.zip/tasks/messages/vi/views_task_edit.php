<?php
return array (
  '<strong>Create</strong> new task' => '<strong>Tạo</strong> công việc mới',
  '<strong>Edit</strong> task' => '<strong>Chỉnh sửa</strong> công việc',
  'Assign users' => 'Giao việc',
  'Cancel' => 'Hủy',
  'Deadline' => 'Thời hạn',
  'Save' => 'Lưu',
  'What is to do?' => 'Phải làm gì?',
);

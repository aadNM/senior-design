<?php
return array (
  'Assign users to this task' => 'Giao công việc này cho các cộng sự',
  'Deadline for this task?' => 'Thời hạn cho công việc này?',
  'Preassign user(s) for this task.' => 'Giao trước người phụ trách cho công việc này.',
  'What to do?' => 'Phải làm gì?',
);

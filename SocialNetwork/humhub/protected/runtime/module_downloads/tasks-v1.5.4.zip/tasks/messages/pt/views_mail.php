<?php
return array (
  'Your Reminder for task {task}' => 'O teu aviso para a tarefa {task}',
);

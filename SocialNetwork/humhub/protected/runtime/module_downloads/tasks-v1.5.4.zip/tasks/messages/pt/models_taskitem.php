<?php
return array (
  'Completed' => 'Completa',
  'Title' => 'Título',
);

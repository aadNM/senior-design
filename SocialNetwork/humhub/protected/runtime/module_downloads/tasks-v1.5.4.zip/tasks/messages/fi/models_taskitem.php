<?php
return array (
  'Completed' => 'Valmistuneet',
  'Title' => 'Otsikko',
);

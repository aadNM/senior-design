<?php
return array (
  '<strong>Your</strong> tasks' => '<strong>Dine</strong> oppgaver',
);

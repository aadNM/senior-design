<?php
return array (
  'Completed' => '',
  'Title' => 'Tiêu đề',
);

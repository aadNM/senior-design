<?php
return array (
  'Anyone can work on this task!' => 'Qualquer pessoa pode trabalhar nesta tarefa!',
  'Open Task' => 'Abrir Tarefa',
  'This task can only be processed by assigned and responsible users.' => 'Esta tarefa só pode ser processada por quem recebeu atribuição ou é responsável por ela.',
);

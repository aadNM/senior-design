<?php
return array (
  'Click, to finish this task' => 'Clica para completar a tarefa',
  'This task is already done. Click to reopen.' => 'Esta tarefa já está completa. Clica para reabrir.',
);

<?php
return array (
  'Anyone can work on this task!' => 'Nikt nie może pracować nad tym zadaniem!',
  'Open Task' => 'Otwórz zadanie',
  'This task can only be processed by assigned and responsible users.' => 'To zadanie może być wykonane tylko przez przypisane do niego osoby.',
);

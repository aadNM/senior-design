<?php
return array (
  'Your Reminder for task {task}' => 'Uw herinnering voor taak {task}',
);

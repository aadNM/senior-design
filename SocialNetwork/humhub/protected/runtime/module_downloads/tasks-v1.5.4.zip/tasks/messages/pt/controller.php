<?php
return array (
  'Already requested' => 'Já pedido',
  'Request sent' => 'Pedido enviado',
  'You have insufficient permissions to perform that operation!' => 'Não tens permissões suficientes para executar essa operação!',
);

<?php

return [
    '<strong>Task</strong> module configuration' => '<strong>Tehtävät</strong> laajennuksen hallinta',
    'Max tasks items' => 'Maksimi tehtävien määrä',
    'Show snippet' => 'Näytä kappale',
    'Show snippet in Space' => 'Näytä kappalle sivulla',
    'Shows a widget with tasks on the dashboard where you are assigned/responsible.' => 'Näyttää widgetin, joka näyttää tähtävät joihin sinut on määrätty/vastuussa.',
    'Shows the widget also on the dashboard of spaces.' => 'Näyttää widgetti myös sivujen etusivuilla.',
    'Sort order' => 'Lajittelujärjestys',
    'Your tasks snippet' => 'Tehtäväsi kappale',
    'Displays a global task menu item on the main menu.' => '',
    'Global task menu item' => '',
    'Menu Item sort order' => '',
    'Show global task menu item' => '',
];

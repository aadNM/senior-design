<?php
return array (
  'Completed' => 'Voltooid',
  'Title' => 'Samenvatting',
);

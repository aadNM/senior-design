<?php
return array (
  'Could not access task!' => 'Không thể tạo công việc!',
);

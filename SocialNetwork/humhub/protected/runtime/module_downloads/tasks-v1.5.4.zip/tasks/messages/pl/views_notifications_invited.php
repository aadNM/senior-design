<?php
return array (
  '{userName} assigned you as responsible person in task {task} from space {spaceName}.' => '{userName} został/a przypisany/a jako osoba odpowiedzialna w zadaniu {task} ze strefy {spaceName}.',
);

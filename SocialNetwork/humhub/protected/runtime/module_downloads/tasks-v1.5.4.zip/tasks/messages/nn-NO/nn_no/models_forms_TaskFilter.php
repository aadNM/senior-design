<?php

return [
    'Created by me' => '',
    'End date' => '',
    'Filter status' => '',
    'Filter tasks' => '',
    'I\'m assigned' => '',
    'I\'m responsible' => '',
    'Overdue' => '',
    'Spaces' => '',
    'Start date' => '',
    'Status' => '',
    'Title' => '',
];

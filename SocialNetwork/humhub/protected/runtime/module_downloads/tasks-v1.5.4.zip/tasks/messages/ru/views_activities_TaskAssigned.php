<?php
return array (
  '{userName} assigned to task {task}.' => '{userName} назначен для выполнения задачи {task}.',
);

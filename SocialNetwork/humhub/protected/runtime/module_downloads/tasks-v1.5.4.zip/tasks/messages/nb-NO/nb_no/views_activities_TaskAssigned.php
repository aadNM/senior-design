<?php
return array (
  '{userName} assigned to task {task}.' => '{userName} tilknyttet oppgave {task}.',
);

<?php
return array (
  '{userName} completed task {task}.' => '{userName} wykonał/a zadanie {task}.',
  '{userName} reset task {task}.' => '{userName} zresetował/a zadanie {task}.',
  '{userName} reviewed task {task}.' => '{userName} przeprowadził/a przegląd zadania {task}.',
  '{userName} works on task {task}.' => '{userName} rozpoczął/ęła pracę nad zadaniem {task}.',
);

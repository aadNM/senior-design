<?php
return array (
  '<strong>Task</strong> module configuration' => '<strong>Configuração</strong> do módulo Tarefa',
  'Displays a global task menu item on the main menu.' => 'Mostrar um menu global de tarefas no menu principal',
  'Global task menu item' => 'Menu global de tarefas',
  'Max tasks items' => 'Máximo de items de tarefas',
  'Menu Item sort order' => 'Ordenação do menu de itens',
  'Show global task menu item' => 'Mostrar menu global de tarefas',
  'Show snippet' => 'Mostrar excerto',
  'Show snippet in Space' => 'Mostrar excerto no Espaço',
  'Shows a widget with tasks on the dashboard where you are assigned/responsible.' => 'Mostrar um widget com tarefas no painel onde estás atribuído/és responsável.',
  'Shows the widget also on the dashboard of spaces.' => 'Mostrar também o widget no painel dos espaços.',
  'Sort order' => 'Ordem',
  'Your tasks snippet' => 'Excerto das tuas tarefas',
);

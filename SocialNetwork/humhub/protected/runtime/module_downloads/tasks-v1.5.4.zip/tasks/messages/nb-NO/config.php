<?php
return array (
  '<strong>Task</strong> module configuration' => '<strong>Oppgave</strong> modul konfigurasjon',
  'Displays a global task menu item on the main menu.' => '',
  'Global task menu item' => '',
  'Max tasks items' => 'Maksimum oppgave elementer',
  'Menu Item sort order' => '',
  'Show global task menu item' => '',
  'Show snippet' => 'Vis snippet',
  'Show snippet in Space' => 'Vis utdrag i gruppen',
  'Shows a widget with tasks on the dashboard where you are assigned/responsible.' => 'Viser en widget med oppgaver på dashbordet hvor du er tildelt / ansvarlig.',
  'Shows the widget also on the dashboard of spaces.' => 'Viser widgeten også på dashbordet i gruppen',
  'Sort order' => 'Sorteringsrekkefølge',
  'Your tasks snippet' => 'Dine oppgave utdrag',
);

<?php
return array (
  '{userName} assigned to task {task}.' => '{userName} atribuído à tarefa {task}.',
);

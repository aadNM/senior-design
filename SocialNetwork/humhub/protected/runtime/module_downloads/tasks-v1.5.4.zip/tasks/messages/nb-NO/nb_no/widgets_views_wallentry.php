<?php
return array (
  'Anyone can work on this task!' => 'Hvem som helst kan jobbe med denne oppgaven.',
  'Open Task' => 'Åpen oppgave',
  'This task can only be processed by assigned and responsible users.' => 'Denne oppgaven kan kun bli håndtert av brukeren som har fått den tildelt og er ansvarlig.',
);

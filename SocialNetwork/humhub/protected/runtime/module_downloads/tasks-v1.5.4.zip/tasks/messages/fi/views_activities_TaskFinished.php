<?php
return array (
  '{userName} finished task {task}.' => '{userName} sai tehtävän {task} valmiiksi.',
);

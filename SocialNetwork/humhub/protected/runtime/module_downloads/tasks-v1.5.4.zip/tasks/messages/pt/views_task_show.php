<?php
return array (
  '<strong>Confirm</strong> deleting' => '<strong>Confirmar</strong> a eliminação',
  'Add Task' => 'Adicionar tarefa',
  'Cancel' => 'Cancelar',
  'Delete' => 'Apagar',
  'Do you really want to delete this task?' => 'Queres mesmo apagar esta tarefa?',
  'No open tasks...' => 'Sem tarefas abertas...',
  'completed tasks' => 'Tarefas terminadas',
);

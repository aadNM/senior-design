<?php
return array (
  'Already requested' => '',
  'Request sent' => '',
  'You have insufficient permissions to perform that operation!' => 'Tev nav pietiekošas pieejas lai veiktu šo darbību!',
);

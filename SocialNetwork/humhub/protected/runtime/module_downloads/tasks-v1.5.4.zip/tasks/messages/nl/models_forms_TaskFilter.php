<?php
return array (
  'Created by me' => 'Gemaakt door mij',
  'End date' => 'Einddatum',
  'Filter status' => 'Filterstatus',
  'Filter tasks' => 'Filter taken',
  'I\'m assigned' => 'Toegewezen aan mij',
  'I\'m responsible' => 'Mijn verantwoordelijkheid',
  'Overdue' => 'Over tijd',
  'Spaces' => 'Ruimten',
  'Start date' => 'Begindatum',
  'Status' => 'Voortgang',
  'Title' => 'Benaming',
);

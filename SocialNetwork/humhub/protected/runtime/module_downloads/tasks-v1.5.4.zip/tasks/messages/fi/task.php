<?php
return array (
  'Allows the user to create, delete and edit tasks and lists and also sort tasks and lists' => 'Antaa käyttäjän luoda, poistaa ja muokata tehtäviä ja listoja sekä lajitella tehtäviä ja listoja',
  'Allows the user to process unassigned tasks' => 'Sallii käyttäjän käsitellä määrittämättömiä tehtäviä',
  'Manage tasks' => 'Hallitse tehtäviä',
  'Process unassigned tasks' => 'Käsittele määrittämättömiä tehtäviä',
);

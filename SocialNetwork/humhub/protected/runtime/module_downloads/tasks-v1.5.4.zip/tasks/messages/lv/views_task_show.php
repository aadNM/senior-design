<?php
return array (
  '<strong>Confirm</strong> deleting' => '',
  'Add Task' => '',
  'Cancel' => 'Atcelt',
  'Delete' => 'Dzēst',
  'Do you really want to delete this task?' => '',
  'No open tasks...' => '',
  'completed tasks' => '',
);

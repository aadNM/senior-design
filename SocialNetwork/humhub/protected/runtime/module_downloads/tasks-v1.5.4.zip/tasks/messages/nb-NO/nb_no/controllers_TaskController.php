<?php
return array (
  'Could not access task!' => 'Kunne ikke åpne oppgave!',
);

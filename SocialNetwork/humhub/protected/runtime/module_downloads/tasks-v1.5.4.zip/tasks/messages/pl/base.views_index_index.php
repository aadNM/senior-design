<?php
return array (
  'Drag list' => 'Przeciągnij listę',
);

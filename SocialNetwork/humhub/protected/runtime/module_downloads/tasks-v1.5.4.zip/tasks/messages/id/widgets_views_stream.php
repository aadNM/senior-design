<?php
return array (
  '<b>There are no tasks yet!</b>' => '',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '',
  'Assigned to me' => '',
  'Created by me' => '',
  'Creation time' => '',
  'Filter' => 'Filter',
  'Last update' => '',
  'Nobody assigned' => '',
  'Sorting' => '',
  'State is finished' => '',
  'State is open' => '',
);

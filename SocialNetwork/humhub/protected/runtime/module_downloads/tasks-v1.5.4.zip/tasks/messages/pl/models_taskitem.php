<?php
return array (
  'Completed' => 'Zakończone',
  'Title' => 'Nazwa',
);

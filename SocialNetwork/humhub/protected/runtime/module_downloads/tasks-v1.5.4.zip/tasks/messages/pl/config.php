<?php
return array (
  '<strong>Task</strong> module configuration' => '<strong>Zadania</strong> - konfiguracja modułu',
  'Displays a global task menu item on the main menu.' => 'Wyświetlaj menu globalnych zadań w głównym menu.',
  'Global task menu item' => 'Przedmiot menu globalnych zadań',
  'Max tasks items' => 'Maksymalna liczba przedmiotów',
  'Menu Item sort order' => 'Kolejność sortowania przedmiotów menu',
  'Show global task menu item' => 'Pokazuj zadanie z globalnego menu zadań',
  'Show snippet' => 'Pokazuj panel',
  'Show snippet in Space' => 'Pokazuj panel w strefie',
  'Shows a widget with tasks on the dashboard where you are assigned/responsible.' => 'Pokaż widget z zadaniami na kokpicie jeśli jesteś przypisany/a lub odpowiedzialny/a.',
  'Shows the widget also on the dashboard of spaces.' => 'Pokazuj widget także na stronach stref.',
  'Sort order' => 'Sortowanie',
  'Your tasks snippet' => 'Twój panel zadań',
);

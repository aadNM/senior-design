<?php
return array (
  'Task Users have been notified' => 'Oppgave bruker er blitt varslet',
);

<?php
return array (
  '1 Day before' => '1 dzień przed',
  '1 Month before' => '1 miesiąc przed',
  '1 Week before' => '1 tydzień przed',
  '2 Days before' => '2 dni przed',
  '2 Weeks before' => '2 tygodnie przed',
  '3 Weeks before' => '3 tygodnie przed',
  'At least 1 Hour before' => 'Przynajmniej godzinę przed',
  'At least 2 Hours before' => 'Przynajmniej dwie godziny przed',
  'Do not remind' => 'Nie przypominaj',
  'Remind Mode' => 'Tryb przypomnienia',
  'Task' => 'Zadanie',
);

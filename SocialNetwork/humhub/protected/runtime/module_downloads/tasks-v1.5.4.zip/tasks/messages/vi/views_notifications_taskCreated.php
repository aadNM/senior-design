<?php
return array (
  '{userName} created a new task {task}.' => '{userName} đã tạo công việc mới {task}.',
);

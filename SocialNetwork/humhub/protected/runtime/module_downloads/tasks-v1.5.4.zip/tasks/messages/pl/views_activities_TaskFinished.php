<?php
return array (
  '{userName} finished task {task}.' => '{userName} zakończył zadanie {task}.',
);

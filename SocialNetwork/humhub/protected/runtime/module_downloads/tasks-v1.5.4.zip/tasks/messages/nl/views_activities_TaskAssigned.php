<?php
return array (
  '{userName} assigned to task {task}.' => '{userName} toegewezen aan taak {task}.',
);

<?php
return array (
  'Do you want to handle this task?' => 'Wilt u deze taak behandelen?',
  'I do it!' => 'Ik doe het!',
);

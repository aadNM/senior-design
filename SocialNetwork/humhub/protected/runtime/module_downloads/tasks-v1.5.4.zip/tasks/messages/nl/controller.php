<?php
return array (
  'Already requested' => 'Al aangevraagd',
  'Request sent' => 'Verzoek verzonden',
  'You have insufficient permissions to perform that operation!' => 'U hebt onvoldoende bevoegdheid om deze bewerking uit te voeren!',
);

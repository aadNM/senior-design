<?php
return array (
  '{userName} completed task {task}.' => '{userName} har fulført oppgaven {task}.',
  '{userName} reset task {task}.' => '{userName} har tilbakestilt oppgaven {task}.',
  '{userName} reviewed task {task}.' => '{userName} gjennomgår oppgaven {task}.',
  '{userName} works on task {task}.' => '{userName} arbeider med oppgaven {task}.',
);

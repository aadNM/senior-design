<?php
return array (
  'Completed' => 'Completado',
  'Title' => 'Título',
);

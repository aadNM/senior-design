<?php
return array (
  '%displayName% cannot attend %contentTitle%.' => '%displayName% δεν μπορεί να παρευρεθεί %contentTitle%.',
  '%displayName% is attending %contentTitle%.' => '%displayName% παρακολουθεί %contentTitle%.',
  '%displayName% might be attending %contentTitle%.' => '%displayName% μπορεί να παρευρεθεί %contentTitle%.',
);

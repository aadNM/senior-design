<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Filter</strong> gebeurtenissen',
  '<strong>Select</strong> calendars' => '<strong>Selecteer</strong> agendas',
  'Followed spaces' => 'Gevolgde ruimtes',
  'Followed users' => 'Gevolgde gebruikers',
  'I\'m attending' => 'Ik ben aanwezig',
  'My events' => 'Mijn gebeurtenissen',
  'My profile' => 'Mijn profiel',
  'My spaces' => 'Mijn ruimtes',
);

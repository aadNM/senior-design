<?php
return array (
  ':count attending' => ':count Zusagen',
  ':count declined' => ':count Ablehnungen',
  ':count maybe' => ':count Vielleicht',
  'Participants' => 'Teilnehmer',
);

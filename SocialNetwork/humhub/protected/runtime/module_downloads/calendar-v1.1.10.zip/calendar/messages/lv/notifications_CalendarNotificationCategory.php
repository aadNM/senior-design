<?php
return array (
  'Calendar' => 'Kalendārs',
  'Receive Calendar related Notifications.' => '',
);

<?php
return array (
  '%displayName% cannot attend %contentTitle%.' => '%displayName% nem vehet részt ebben: %contentTitle%.',
  '%displayName% is attending %contentTitle%.' => '%displayName% részt vehet itt: %contentTitle%.',
  '%displayName% might be attending %contentTitle%.' => '%displayName% esetleg részt vehet itt: %contentTitle%.',
);

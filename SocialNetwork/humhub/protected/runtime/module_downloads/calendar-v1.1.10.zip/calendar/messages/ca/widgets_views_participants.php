<?php
return array (
  ':count attending' => ':count hi aniran',
  ':count declined' => ':count no hi aniran',
  ':count maybe' => ':count potser hi aniran',
  'Participants' => 'Participants',
);

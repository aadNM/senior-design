<?php
return array (
  '<strong>Starting</strong> {date}' => '<strong>Começando</strong> em {date}',
  'Additional information:' => 'Informação adicional:',
  'Location:' => 'Localização:',
  'Organized by {userName}' => 'Organizado por {userName}',
  'View Online: {url}' => 'Ver online: {url}',
);

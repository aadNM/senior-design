<?php

return [
    'Attend' => 'Dalyvauti',
    'Decline' => 'Atmesti',
    'Maybe' => 'Galbūt',
    'Additional information' => '',
];

<?php

return [
    'Attend' => 'Προσέχω',
    'Decline' => 'Άρνηση',
    'Maybe' => 'Ίσως',
    'Additional information' => '',
];

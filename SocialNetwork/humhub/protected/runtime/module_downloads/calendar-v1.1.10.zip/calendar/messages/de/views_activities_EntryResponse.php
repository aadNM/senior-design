<?php
return array (
  '%displayName% cannot attend %contentTitle%.' => '%displayName% kann nicht teilnehmen an %contentTitle%.',
  '%displayName% is attending %contentTitle%.' => '%displayName% nimmt teil an %contentTitle%.',
  '%displayName% might be attending %contentTitle%.' => '%displayName% nimmt vielleicht teil an %contentTitle%.',
);

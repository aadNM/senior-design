<?php

return [
    'Attend' => 'Participă',
    'Decline' => 'Respinge',
    'Maybe' => 'Probabil',
    'Additional information' => '',
];

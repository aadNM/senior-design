<?php
return array (
  '<strong>Create</strong> event' => '',
  '<strong>Edit</strong> event' => '',
  '<strong>Edit</strong> recurring event' => '',
  'Basic' => 'الأساسي',
  'Everybody can participate' => '',
  'Files' => 'الملفات',
  'No participants' => '',
  'Participation' => '',
  'Recurrence' => '',
  'Reminder' => '',
  'Select event type...' => '',
  'Title' => 'العنوان',
);

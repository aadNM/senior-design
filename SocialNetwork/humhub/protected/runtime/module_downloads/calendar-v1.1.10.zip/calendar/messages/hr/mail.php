<?php
return array (
  '<strong>Starting</strong> {date}' => '<strong>Početak</strong> {date}',
  'Additional information:' => 'Dodatne informacije:',
  'Location:' => 'Lokacija:',
  'Organized by {userName}' => 'Organizirano od {userName}',
  'View Online: {url}' => 'Pregledajte na mreži: {url}',
);

<?php
return array (
  'Participation' => 'Partecipazione',
  'Reminder' => 'Promemoria',
);

<?php
return array (
  '<strong>Upcoming</strong> events ' => '<strong>Anstehende</strong> Veranstaltungen',
  'Open Calendar' => 'Kalender öffnen',
);

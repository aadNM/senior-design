<?php
return array (
  '<strong>Create</strong> event' => '<strong>Criar</strong> evento',
  '<strong>Edit</strong> event' => '<strong>Editar</strong> evento',
  '<strong>Edit</strong> recurring event' => '<strong>Editar</strong> evento periódico',
  'Basic' => 'Básico',
  'Everybody can participate' => 'Todas as pessoas podem participar',
  'Files' => 'Ficheiros',
  'No participants' => 'Sem participantes',
  'Participation' => 'Participação',
  'Recurrence' => 'Repetição',
  'Reminder' => 'Aviso',
  'Select event type...' => 'Selecciona o tipo do evento...',
  'Title' => 'Título',
);

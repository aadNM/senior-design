<?php
return array (
  'day' => '',
  'list' => 'liste',
  'month' => '',
  'today' => 'bugün',
  'week' => '',
);

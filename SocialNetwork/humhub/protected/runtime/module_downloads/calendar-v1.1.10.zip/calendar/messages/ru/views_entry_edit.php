<?php

return [
    '<strong>Create</strong> event' => '<strong>Создать</strong> событие',
    '<strong>Edit</strong> event' => '<strong>Редактировать</strong> событие',
    'Basic' => 'Основной',
    'Everybody can participate' => 'Любой может принять участие',
    'Files' => 'Файлы',
    'No participants' => 'Нет участников',
    'Title' => 'Наименование',
    '<strong>Edit</strong> recurring event' => '',
    'Participation' => '',
    'Recurrence' => '',
    'Reminder' => '',
    'Select event type...' => '',
];

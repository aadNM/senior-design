<?php
return array (
  '{displayName} canceled event "{contentTitle}" in space {spaceName}.' => 'Ο/η {displayName} ακύρωσε εκδήλωση "{contentTitle}" στον χώρο {spaceName}.',
  '{displayName} canceled event "{contentTitle}".' => 'Ο/η {displayName} ακύρωσε εκδήλωση "{contentTitle}".',
  '{displayName} just added you to event "{contentTitle}".' => 'Ο/η {displayName} Μόλις σας πρόσθεσε στην εκδήλωση "{contentTitle}".',
  '{displayName} just updated event "{contentTitle}" in space {spaceName}.' => 'Ο/η {displayName} μόλις ενημέρωσε εκδήλωση "{contentTitle}" στον χώρο {spaceName}.',
  '{displayName} just updated event {contentTitle}.' => 'Ο/η {displayName} μόλις ενημέρωσε εκδήλωση {contentTitle}.',
  '{displayName} reopened event "{contentTitle}" in space {spaceName}.' => 'Ο/η {displayName} επανάνοιξε εκδήλωση "{contentTitle}" στον χώρο {spaceName}.',
  '{displayName} reopened event "{contentTitle}".' => 'Ο/η {displayName} επανάνοιξε εκδήλωση "{contentTitle}".',
);

<?php

return [
    ':count attending' => '',
    ':count declined' => '',
    ':count maybe' => '',
    'Participants' => '',
];

<?php
return array (
  '%displayName% created a new %contentTitle%.' => 'Ο/η %displayName% δημιούργησε ένα νέο %contentTitle%.',
);

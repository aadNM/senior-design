<?php
return array (
  '<strong>Create</strong> new event type' => '<strong>Δημιουργία</strong> νέου τύπου εκδήλωσης',
  '<strong>Edit</strong> calendar' => '<strong>Επεξεργασία</strong> ημερολογίου',
  '<strong>Edit</strong> event type' => '<strong>Επεξεργασία</strong> τύπου εκδήλωσης',
);

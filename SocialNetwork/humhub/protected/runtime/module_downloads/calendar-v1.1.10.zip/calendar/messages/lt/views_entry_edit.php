<?php

return [
    '<strong>Create</strong> event' => '<strong>Sukurti</strong> įvykį',
    '<strong>Edit</strong> event' => '<strong>Redaguoti</strong> įvykį',
    'Basic' => 'Pagrindinis',
    'Everybody can participate' => 'Dalyvauti gali visi',
    'Files' => 'Failai',
    'No participants' => 'Nėra dalyvių',
    'Title' => 'Pavadinimas',
    '<strong>Edit</strong> recurring event' => '',
    'Participation' => '',
    'Recurrence' => '',
    'Reminder' => '',
    'Select event type...' => '',
];

<?php
return array (
  'day' => '',
  'list' => '',
  'month' => '',
  'today' => 'šodien',
  'week' => '',
);

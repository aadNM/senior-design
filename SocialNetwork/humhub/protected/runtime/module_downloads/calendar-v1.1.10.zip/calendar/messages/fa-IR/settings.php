<?php

return [
    'Participation' => '',
    'Reminder' => '',
];

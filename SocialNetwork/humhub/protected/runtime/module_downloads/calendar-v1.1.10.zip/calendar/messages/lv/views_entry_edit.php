<?php

return [
    '<strong>Create</strong> event' => '<strong>Izveidot</strong> pasākumu',
    '<strong>Edit</strong> event' => '<strong>Rediģēt</strong> pasākumu',
    'Basic' => 'Pamata',
    'Everybody can participate' => 'Visi var piedalīties',
    'Files' => 'Faili',
    'No participants' => 'Nav dalībnieku',
    'Title' => 'Nosaukum',
    '<strong>Edit</strong> recurring event' => '',
    'Participation' => '',
    'Recurrence' => '',
    'Reminder' => '',
    'Select event type...' => '',
];

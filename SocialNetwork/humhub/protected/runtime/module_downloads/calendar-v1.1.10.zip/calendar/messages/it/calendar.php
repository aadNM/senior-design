<?php
return array (
  'day' => 'giorno',
  'list' => 'elenco',
  'month' => 'mese',
  'today' => 'oggi',
  'week' => 'settimana',
);

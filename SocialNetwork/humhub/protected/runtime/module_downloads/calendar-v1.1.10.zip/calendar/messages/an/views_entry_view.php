<?php

return [
    'Additional information' => '',
    'Attend' => '',
    'Decline' => '',
    'Maybe' => '',
];

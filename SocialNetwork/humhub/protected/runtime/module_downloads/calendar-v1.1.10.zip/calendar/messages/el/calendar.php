<?php
return array (
  'day' => 'ημέρα',
  'list' => 'λίστα',
  'month' => 'μήνας',
  'today' => 'σήμερα',
  'week' => 'εβδομάδα',
);

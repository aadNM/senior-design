<?php

return [
    'day' => '',
    'list' => '',
    'month' => '',
    'today' => '',
    'week' => '',
];

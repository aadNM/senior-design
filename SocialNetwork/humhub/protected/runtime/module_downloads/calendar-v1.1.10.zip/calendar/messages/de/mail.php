<?php
return array (
  '<strong>Starting</strong> {date}' => '<strong>Start</strong> {date}',
  'Additional information:' => 'Zusätzliche Informationen:',
  'Location:' => 'Ort:',
  'Organized by {userName}' => 'Organisiert durch {userName}',
  'View Online: {url}' => 'Online ansehen: {url}',
);

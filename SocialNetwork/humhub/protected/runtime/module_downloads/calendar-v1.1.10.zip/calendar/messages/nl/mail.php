<?php
return array (
  '<strong>Starting</strong> {date}' => '<strong>Start</strong> {date}',
  'Additional information:' => 'Extra informatie:',
  'Location:' => 'Plaats:',
  'Organized by {userName}' => 'Georganiseerd door {userName}',
  'View Online: {url}' => 'Online bekijken: {url}',
);

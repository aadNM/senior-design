<?php

return [
    '{displayName} canceled event "{contentTitle}" in space {spaceName}.' => '',
    '{displayName} canceled event "{contentTitle}".' => '',
    '{displayName} just added you to event "{contentTitle}".' => '',
    '{displayName} just updated event "{contentTitle}" in space {spaceName}.' => '',
    '{displayName} just updated event {contentTitle}.' => '',
    '{displayName} reopened event "{contentTitle}" in space {spaceName}.' => '',
    '{displayName} reopened event "{contentTitle}".' => '',
];

<?php

return [
    'Decline' => 'رفض',
    'Additional information' => '',
    'Attend' => '',
    'Maybe' => '',
];

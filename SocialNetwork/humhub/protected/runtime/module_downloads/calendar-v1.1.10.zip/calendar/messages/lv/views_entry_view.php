<?php

return [
    'Attend' => 'Piedalīties',
    'Decline' => 'Noraidīt',
    'Maybe' => 'Varbūt',
    'Additional information' => '',
];

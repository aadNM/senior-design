<?php

return [
    'Attend' => 'حضور',
    'Decline' => 'انصراف',
    'Maybe' => 'احتمالا',
    'Additional information' => '',
];

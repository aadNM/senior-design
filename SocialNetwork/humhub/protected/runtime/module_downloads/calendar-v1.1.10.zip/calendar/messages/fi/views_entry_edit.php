<?php
return array (
  '<strong>Create</strong> event' => '<strong>Luo</strong> tapahtuma',
  '<strong>Edit</strong> event' => '<strong>Muokkaa</strong> tapahtumaa',
  '<strong>Edit</strong> recurring event' => '',
  'Basic' => 'Tavallinen',
  'Everybody can participate' => 'Kaikki voivat osallistua',
  'Files' => 'Tiedostot',
  'No participants' => 'Ei osallistujia',
  'Participation' => 'osallistujat',
  'Recurrence' => '',
  'Reminder' => 'Muistutus',
  'Select event type...' => 'Valitse tapahtumatyyppi...',
  'Title' => 'Otsikko',
);

<?php
return array (
  ':count attending' => ':count prisustvuje',
  ':count declined' => ':count odbijenica',
  ':count maybe' => ':count možda',
  'Participants' => 'Sudionici',
);

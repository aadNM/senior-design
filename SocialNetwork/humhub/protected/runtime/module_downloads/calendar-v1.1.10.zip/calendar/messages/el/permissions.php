<?php
return array (
  'Allows the user to create new calendar entries' => 'Επιτρέπει στον χρήστη τη δημιουργία νέων καταχωρήσεων ημερολογίου',
  'Allows the user to edit/delete existing calendar entries' => 'Επιτρέπει στον χρήστη να επεξεργάζεται/διαγράφει τις υπάρχουσες καταχωρήσεις ημερολογίου',
  'Create entry' => 'Δημιουργία καταχώρησης',
  'Manage entries' => 'Διαχείριση καταχωρήσεων',
);

<?php

return [
    'Title' => 'Titulek',
    '<strong>Create</strong> event' => '',
    '<strong>Edit</strong> event' => '',
    '<strong>Edit</strong> recurring event' => '',
    'Basic' => '',
    'Everybody can participate' => '',
    'Files' => '',
    'No participants' => '',
    'Participation' => '',
    'Recurrence' => '',
    'Reminder' => '',
    'Select event type...' => '',
];

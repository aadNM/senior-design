<?php
return array (
  '{displayName} canceled event "{contentTitle}" in space {spaceName}.' => '{displayName} cancelou o evento "{contentTitle}" no espaço {spaceName}.',
  '{displayName} canceled event "{contentTitle}".' => '{displayName} cancelou o evento "{contentTitle}".',
  '{displayName} just added you to event "{contentTitle}".' => '{displayName} adicionou-te ao evento "{contentTitle}".',
  '{displayName} just updated event "{contentTitle}" in space {spaceName}.' => '{displayName} actualizou o evento "{contentTitle}" no espaço {spaceName}.',
  '{displayName} just updated event {contentTitle}.' => '{displayName} acabou de actualizar o evento {contentTitle}.',
  '{displayName} reopened event "{contentTitle}" in space {spaceName}.' => '{displayName} reabriu o evento "{contentTitle}" no espaço {spaceName}.',
  '{displayName} reopened event "{contentTitle}".' => '{displayName} reabriu o evento "{contentTitle}".',
);

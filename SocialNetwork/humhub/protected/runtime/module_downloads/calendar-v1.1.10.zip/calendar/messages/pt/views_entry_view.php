<?php
return array (
  'Additional information' => 'Informação adicional',
  'Attend' => 'Vou',
  'Decline' => 'Não vou',
  'Maybe' => 'Talvez',
);

<?php
return array (
  'Calendar' => 'Calandario',
  'Receive Calendar related Notifications.' => '',
);

<?php
return array (
  ':count attending' => ':count bisa menghadiri',
  ':count declined' => ':count tidak menghadiri',
  ':count maybe' => ':count mungkin',
  'Participants' => 'Partisipasi',
);

<?php

return [
    'Attend' => 'Hi assistiré',
    'Decline' => 'No hi assistiré',
    'Maybe' => 'Potser',
    'Additional information' => '',
];

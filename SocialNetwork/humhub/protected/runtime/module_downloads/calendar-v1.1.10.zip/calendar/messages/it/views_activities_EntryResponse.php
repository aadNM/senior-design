<?php
return array (
  '%displayName% cannot attend %contentTitle%.' => '%displayName% non può partecipare a %contentTitle%.',
  '%displayName% is attending %contentTitle%.' => '%displayName% sta partecipando a %contentTitle%.',
  '%displayName% might be attending %contentTitle%.' => '%displayName% potrebbe partecipare a %contentTitle%.',
);

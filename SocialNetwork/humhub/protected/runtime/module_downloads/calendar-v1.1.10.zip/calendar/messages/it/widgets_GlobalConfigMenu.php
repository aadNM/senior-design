<?php
return array (
  'Calendars' => 'Calendari',
  'Defaults' => 'Predefinite',
  'Event Types' => 'Tipi di evento',
  'Snippet' => 'Snippet',
);

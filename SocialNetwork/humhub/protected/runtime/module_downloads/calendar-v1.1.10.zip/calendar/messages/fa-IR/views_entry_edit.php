<?php

return [
    '<strong>Create</strong> event' => '<strong>ساختن</strong> گروه',
    '<strong>Edit</strong> event' => '<strong>ویرایش</strong> گروه',
    'Basic' => 'پايه',
    'Everybody can participate' => 'همه می‌توانند مشارکت کنند',
    'Files' => 'فايل ها',
    'No participants' => 'مشارکت‌کننده‌ای وجود ندارد',
    'Title' => 'عنوان',
    '<strong>Edit</strong> recurring event' => '',
    'Participation' => '',
    'Recurrence' => '',
    'Reminder' => '',
    'Select event type...' => '',
];

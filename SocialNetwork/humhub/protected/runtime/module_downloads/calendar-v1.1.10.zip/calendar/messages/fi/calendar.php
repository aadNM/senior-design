<?php
return array (
  'day' => '',
  'list' => 'lista',
  'month' => '',
  'today' => 'tänään',
  'week' => '',
);

<?php
return array (
  '<strong>Create</strong> event' => 'Termin <strong>erstellen</strong>',
  '<strong>Edit</strong> event' => 'Termin <strong>bearbeiten</strong>',
  '<strong>Edit</strong> recurring event' => '<strong>Wiederkehrenden Termin</strong> bearbeiten',
  'Basic' => 'Allgemein',
  'Everybody can participate' => 'Jeder darf teilnehmen',
  'Files' => 'Dateien',
  'No participants' => 'Keine Teilnehmer',
  'Participation' => 'Teilnahmemodus',
  'Recurrence' => 'Wiederkehrende Termine',
  'Reminder' => 'Erinnerung',
  'Select event type...' => 'Kategorie wählen',
  'Title' => 'Titel',
);

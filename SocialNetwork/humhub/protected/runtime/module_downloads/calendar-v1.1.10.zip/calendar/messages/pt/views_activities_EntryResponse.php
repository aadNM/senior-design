<?php
return array (
  '%displayName% cannot attend %contentTitle%.' => '%displayName% não vai a %contentTitle%.',
  '%displayName% is attending %contentTitle%.' => '%displayName% vai a %contentTitle%.',
  '%displayName% might be attending %contentTitle%.' => '%displayName% talvez vá a %contentTitle%.',
);

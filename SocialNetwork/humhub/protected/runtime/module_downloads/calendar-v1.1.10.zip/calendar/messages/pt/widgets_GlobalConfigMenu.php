<?php
return array (
  'Calendars' => 'Calendários',
  'Defaults' => 'Padrões',
  'Event Types' => 'Tipos de evento',
  'Snippet' => 'Excerto',
);

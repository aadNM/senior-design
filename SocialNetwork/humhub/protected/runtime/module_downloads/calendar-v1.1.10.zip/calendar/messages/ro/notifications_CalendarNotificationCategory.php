<?php
return array (
  'Calendar' => 'Calendar',
  'Receive Calendar related Notifications.' => '',
);

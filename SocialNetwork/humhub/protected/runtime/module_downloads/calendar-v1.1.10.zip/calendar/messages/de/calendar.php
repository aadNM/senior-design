<?php
return array (
  'day' => 'Tag',
  'list' => 'Liste',
  'month' => 'Monat',
  'today' => 'Heute',
  'week' => 'Woche',
);

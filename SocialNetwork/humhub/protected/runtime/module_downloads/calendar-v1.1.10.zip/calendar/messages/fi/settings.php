<?php
return array (
  'Participation' => 'osallistujat',
  'Reminder' => 'Muistutus',
);

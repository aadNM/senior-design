<?php
return array (
  'day' => '',
  'list' => '',
  'month' => '',
  'today' => 'اليوم',
  'week' => '',
);

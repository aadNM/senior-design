<?php

return [
    '%displayName% cannot attend %contentTitle%.' => '',
    '%displayName% is attending %contentTitle%.' => '',
    '%displayName% might be attending %contentTitle%.' => '',
];

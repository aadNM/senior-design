<?php
return array (
  'Additional information' => 'Dodatne informacije',
  'Attend' => 'Prisustvo',
  'Decline' => 'Odbij',
  'Maybe' => 'Možda',
);

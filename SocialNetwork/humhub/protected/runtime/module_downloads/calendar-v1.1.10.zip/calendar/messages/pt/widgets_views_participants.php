<?php
return array (
  ':count attending' => ':count vão',
  ':count declined' => ':count não vão',
  ':count maybe' => ':count talvez',
  'Participants' => 'Participantes',
);

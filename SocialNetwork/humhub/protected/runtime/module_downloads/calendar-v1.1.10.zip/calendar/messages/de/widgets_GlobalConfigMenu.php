<?php
return array (
  'Calendars' => 'Kalender',
  'Defaults' => 'Standards',
  'Event Types' => 'Kategorie',
  'Snippet' => 'Widget',
);

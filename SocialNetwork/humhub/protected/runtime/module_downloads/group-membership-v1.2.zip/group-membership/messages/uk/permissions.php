<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Користувачам дозволено самостійно стати членом цієї групи (або вийти)',
  'Users can become a member of this group' => 'Користувачі можуть стати учасниками цієї групи',
);

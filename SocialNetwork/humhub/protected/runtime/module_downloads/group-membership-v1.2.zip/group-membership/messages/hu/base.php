<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Hozzáadja bizonyos csoportok számára annak lehetőségét, hogy a felhasználók maguk is tagok lehessenek',
  'Become member' => 'Legyen tag',
  'Cancel membership' => 'Törölje a tagságot',
  'Group membership' => 'Csoporttagság',
  'Groups of which I am a member' => 'Csoportok, amelyeknek tagja vagyok',
  'My Groups' => 'Saját csoportok',
  'My groups' => 'A csoportjaim',
  'Others groups I can join' => 'Más csoportokhoz csatlakozhatok',
);

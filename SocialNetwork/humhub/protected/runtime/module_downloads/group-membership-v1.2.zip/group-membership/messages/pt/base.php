<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Adiciona a possibilidade de certos grupos permitirem que usuários se tornem membros',
  'Become member' => 'Torne-se membro',
  'Cancel membership' => 'Cancelar a adesão',
  'Group membership' => 'Membros do grupo',
  'Groups of which I am a member' => 'Grupos dos quais sou membro',
  'My Groups' => 'Meus Grupos',
  'My groups' => 'Meus grupos',
  'Others groups I can join' => 'Outros grupos nos quais posso participar',
);

<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Dodaje mogućnost određenim skupinama da korisnicima omoguće da i sami postanu članovi',
  'Become member' => 'Postanite član',
  'Cancel membership' => 'Otkaži članstvo',
  'Group membership' => 'Članstvo u grupi',
  'Groups of which I am a member' => 'Grupe čiji sam član',
  'My Groups' => 'Moje grupe',
  'My groups' => 'Moje grupe',
  'Others groups I can join' => 'Drugim skupinama kojima se mogu pridružiti',
);

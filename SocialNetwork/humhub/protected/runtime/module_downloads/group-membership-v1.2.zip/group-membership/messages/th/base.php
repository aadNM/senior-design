<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'เพิ่มความเป็นไปได้สำหรับบางกลุ่มในการอนุญาตให้ผู้ใช้สมัครเป็นสมาชิกด้วยตนเอง',
  'Become member' => 'สมัครเป็นสมาชิก',
  'Cancel membership' => 'ยกเลิกการเป็นสมาชิก',
  'Group membership' => 'การเป็นสมาชิกกลุ่ม',
  'Groups of which I am a member' => 'กลุ่มที่ฉันเป็นสมาชิก',
  'My Groups' => 'กลุ่มของฉัน',
  'My groups' => 'กลุ่มของฉัน',
  'Others groups I can join' => 'กลุ่มอื่นที่ฉันสามารถเข้าร่วมได้',
);

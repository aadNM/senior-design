<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Poskytuje určitým skupinám možnosť umožniť používateľom stať sa členmi sami',
  'Become member' => 'Staňte sa členom',
  'Cancel membership' => 'Zrušiť členstvo',
  'Group membership' => 'Členstvo v skupine',
  'Groups of which I am a member' => 'Skupiny, ktorých som členom',
  'My Groups' => 'Moje skupiny',
  'My groups' => 'Moje skupiny',
  'Others groups I can join' => 'K ďalším skupinám sa môžem pridať',
);

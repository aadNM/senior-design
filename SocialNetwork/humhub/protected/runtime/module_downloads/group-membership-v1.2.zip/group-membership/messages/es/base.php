<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Agrega la posibilidad de que ciertos grupos permitan a los usuarios convertirse en miembros ellos mismos',
  'Become member' => 'Hazte miembro',
  'Cancel membership' => 'Cancelar membresía',
  'Group membership' => 'Membresía de grupo',
  'Groups of which I am a member' => 'Grupos de los que soy miembro',
  'My Groups' => 'Mis grupos',
  'My groups' => 'Mis grupos',
  'Others groups I can join' => 'Otros grupos a los que puedo unirme',
);

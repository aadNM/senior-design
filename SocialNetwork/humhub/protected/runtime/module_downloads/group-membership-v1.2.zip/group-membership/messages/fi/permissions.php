<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Käyttäjät voivat liittyä tähän ryhmään (tai poistua) itse',
  'Users can become a member of this group' => 'Käyttäjät voivat liittyä tähän ryhmään',
);

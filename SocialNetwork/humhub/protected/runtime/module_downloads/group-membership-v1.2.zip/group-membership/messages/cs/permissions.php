<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Uživatelé se mohou sami stát členy této skupiny (nebo ji opustit)',
  'Users can become a member of this group' => 'Uživatelé se mohou stát členy této skupiny',
);

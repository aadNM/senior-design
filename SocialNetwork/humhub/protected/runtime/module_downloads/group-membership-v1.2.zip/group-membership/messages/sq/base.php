<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Shton mundësinë që grupe të caktuara të lejojnë përdoruesit të bëhen vetë anëtarë',
  'Become member' => 'Bëhuni anëtar',
  'Cancel membership' => 'Anuloni anëtarësimin',
  'Group membership' => 'Anëtarësimi në grup',
  'Groups of which I am a member' => 'Grupet ku unë jam anëtar',
  'My Groups' => 'Grupet e mia',
  'My groups' => 'Grupet e mia',
  'Others groups I can join' => 'Në grupe të tjera mund të bashkohem',
);

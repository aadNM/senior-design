<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Thêm khả năng cho các nhóm nhất định để cho phép người dùng tự trở thành thành viên',
  'Become member' => 'Trở thành thành viên',
  'Cancel membership' => 'Hủy bỏ thành viên',
  'Group membership' => 'Thành viên nhóm',
  'Groups of which I am a member' => 'Các nhóm mà tôi là thành viên',
  'My Groups' => 'Nhóm của tôi',
  'My groups' => 'Nhóm của tôi',
  'Others groups I can join' => 'Những nhóm khác mà tôi có thể tham gia',
);

<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Ajoute posiblite pou sèten gwoup pèmèt itilizatè yo vin manm tèt yo',
  'Become member' => 'Vin manm',
  'Cancel membership' => 'Anile manm',
  'Group membership' => 'Manm gwoup la',
  'Groups of which I am a member' => 'Gwoup kote mwen se yon manm',
  'My Groups' => 'Gwoup mwen yo',
  'My groups' => 'Gwoup mwen yo',
  'Others groups I can join' => 'Lòt gwoup mwen ka rantre',
);

<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'A felhasználók maguk is beléphetnek a csoportba (vagy kiléphetnek)',
  'Users can become a member of this group' => 'A felhasználók tagjai lehetnek ennek a csoportnak',
);

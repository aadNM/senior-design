<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => '사용자는 이 그룹의 구성원이 될 수 있습니다(또는 종료).',
  'Users can become a member of this group' => '사용자는 이 그룹의 구성원이 될 수 있습니다.',
);

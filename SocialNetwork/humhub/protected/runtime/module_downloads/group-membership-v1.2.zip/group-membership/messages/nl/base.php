<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Voegt voor bepaalde groepen de mogelijkheid toe om gebruikers zelf lid te laten worden',
  'Become member' => 'Word lid',
  'Cancel membership' => 'Lidmaatschap annuleren',
  'Group membership' => 'Groepslidmaatschap',
  'Groups of which I am a member' => 'Groepen waarvan ik lid ben',
  'My Groups' => 'Mijn groepen',
  'My groups' => 'Mijn groepen',
  'Others groups I can join' => 'Andere groepen waar ik lid van kan worden',
);

<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'ተጠቃሚዎች ራሳቸው የዚህ ቡድን አባል (ወይም መውጫ) አባል እንዲሆኑ ይፈቀድላቸዋል',
  'Users can become a member of this group' => 'ተጠቃሚዎች የዚህ ቡድን አባል ሊሆኑ ይችላሉ',
);

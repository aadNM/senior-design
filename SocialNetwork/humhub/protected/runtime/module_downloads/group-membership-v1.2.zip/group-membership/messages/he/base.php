<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'מוסיף אפשרות לקבוצות מסוימות לאפשר למשתמשים להיות חברים בעצמם',
  'Become member' => 'הפוך לחבר',
  'Cancel membership' => 'בטל חברות',
  'Group membership' => 'חברות בקבוצה',
  'Groups of which I am a member' => 'קבוצות בהן אני חבר',
  'My Groups' => 'הקבוצות שלי',
  'My groups' => 'הקבוצות שלי',
  'Others groups I can join' => 'קבוצות אחרות שאוכל להצטרף אליהן',
);

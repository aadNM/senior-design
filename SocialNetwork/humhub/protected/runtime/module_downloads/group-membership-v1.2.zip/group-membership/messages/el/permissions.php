<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Επιτρέπεται στους χρήστες να γίνουν οι ίδιοι μέλη αυτής της ομάδας (ή να αποχωρήσουν)',
  'Users can become a member of this group' => 'Οι χρήστες μπορούν να γίνουν μέλη αυτής της ομάδας',
);

<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Përdoruesit lejohen të bëhen vetë anëtarë të këtij grupi (ose të dalin)',
  'Users can become a member of this group' => 'Përdoruesit mund të bëhen anëtarë të këtij grupi',
);

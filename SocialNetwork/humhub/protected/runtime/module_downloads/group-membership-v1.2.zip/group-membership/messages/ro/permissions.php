<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Utilizatorii au voie să devină membri ai acestui grup (sau să iasă) ei înșiși',
  'Users can become a member of this group' => 'Utilizatorii pot deveni membri ai acestui grup',
);

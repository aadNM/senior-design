<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Adaugă posibilitatea ca anumite grupuri să permită utilizatorilor să devină membri înșiși',
  'Become member' => 'Deveniți membru',
  'Cancel membership' => 'Anulați calitatea de membru',
  'Group membership' => 'Membru al grupului',
  'Groups of which I am a member' => 'Grupuri din care fac parte',
  'My Groups' => 'Grupurile mele',
  'My groups' => 'Grupurile mele',
  'Others groups I can join' => 'Alte grupuri la care mă pot alătura',
);

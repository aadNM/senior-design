<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Người dùng được phép trở thành thành viên của nhóm này (hoặc tự thoát)',
  'Users can become a member of this group' => 'Người dùng có thể trở thành thành viên của nhóm này',
);

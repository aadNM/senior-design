<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Itilizatè yo gen dwa vin yon manm nan gwoup sa a (oswa sòti) tèt yo',
  'Users can become a member of this group' => 'Itilizatè yo ka vin yon manm nan gwoup sa a',
);

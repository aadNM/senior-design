<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Додає можливість для певних груп дозволити користувачам самостійно стати учасниками',
  'Become member' => 'Станьте учасником',
  'Cancel membership' => 'Скасувати членство',
  'Group membership' => 'Членство в групі',
  'Groups of which I am a member' => 'Групи, учасником яких я є',
  'My Groups' => 'Мої групи',
  'My groups' => 'Мої групи',
  'Others groups I can join' => 'До інших груп я можу приєднатися',
);

<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Belirli gruplara, kullanıcıların kendilerinin üye olmasına izin verme olasılığını ekler',
  'Become member' => 'Üye ol',
  'Cancel membership' => 'Üyeliği iptal et',
  'Group membership' => 'Grup üyeliği',
  'Groups of which I am a member' => 'Üyesi olduğum gruplar',
  'My Groups' => 'Gruplarım',
  'My groups' => 'gruplarım',
  'Others groups I can join' => 'Katılabileceğim diğer gruplar',
);

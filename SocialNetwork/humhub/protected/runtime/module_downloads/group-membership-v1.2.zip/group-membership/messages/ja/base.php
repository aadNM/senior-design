<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => '特定のグループがユーザー自身でメンバーになることを許可する可能性を追加します',
  'Become member' => 'メンバーになる',
  'Cancel membership' => 'メンバーシップをキャンセルする',
  'Group membership' => 'グループメンバーシップ',
  'Groups of which I am a member' => '私が所属している団体',
  'My Groups' => '私のグループ',
  'My groups' => '私のグループ',
  'Others groups I can join' => '私が参加できる他のグループ',
);

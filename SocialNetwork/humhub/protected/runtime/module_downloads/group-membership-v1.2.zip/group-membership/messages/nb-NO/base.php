<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Legger til muligheten for at bestemte grupper tillater brukere å bli medlem selv',
  'Become member' => 'Bli medlem',
  'Cancel membership' => 'Avbryt medlemskap',
  'Group membership' => 'Gruppemedlemskap',
  'Groups of which I am a member' => 'Grupper som jeg er medlem av',
  'My Groups' => 'Mine grupper',
  'My groups' => 'Mine grupper',
  'Others groups I can join' => 'Andre grupper jeg kan bli med på',
);

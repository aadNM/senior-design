<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Menambahkan kemungkinan bagi grup tertentu untuk mengizinkan pengguna menjadi anggotanya sendiri',
  'Become member' => 'Menjadi anggota',
  'Cancel membership' => 'Batalkan keanggotaan',
  'Group membership' => 'Keanggotaan grup',
  'Groups of which I am a member' => 'Grup di mana saya menjadi anggotanya',
  'My Groups' => 'Grup Saya',
  'My groups' => 'Grup saya',
  'Others groups I can join' => 'Grup lain yang bisa saya ikuti',
);

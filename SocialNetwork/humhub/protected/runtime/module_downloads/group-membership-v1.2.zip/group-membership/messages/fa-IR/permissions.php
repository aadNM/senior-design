<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'کاربران مجازند خودشان عضو این گروه شوند (یا خارج شوند)',
  'Users can become a member of this group' => 'کاربران می توانند عضو این گروه شوند',
);

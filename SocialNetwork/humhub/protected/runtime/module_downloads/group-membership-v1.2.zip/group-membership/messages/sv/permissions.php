<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Användare får själva bli medlemmar i denna grupp (eller lämna)',
  'Users can become a member of this group' => 'Användare kan bli medlem i denna grupp',
);

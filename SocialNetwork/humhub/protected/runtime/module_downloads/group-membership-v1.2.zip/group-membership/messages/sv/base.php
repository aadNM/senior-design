<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Lägger till möjligheten för vissa grupper att låta användare själva bli medlem',
  'Become member' => 'Bli medlem',
  'Cancel membership' => 'Avbryt medlemskap',
  'Group membership' => 'Gruppmedlemskap',
  'Groups of which I am a member' => 'Grupper som jag är medlem i',
  'My Groups' => 'Mina grupper',
  'My groups' => 'Mina grupper',
  'Others groups I can join' => 'Andra grupper jag kan gå med i',
);

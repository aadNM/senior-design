<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Foydalanuvchilar o\'zlari ushbu guruhga a\'zo bo\'lishlari (yoki chiqishlari) mumkin',
  'Users can become a member of this group' => 'Foydalanuvchilar ushbu guruhga a\'zo bo\'lishlari mumkin',
);

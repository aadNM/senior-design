<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Doda možnost, da nekatere skupine uporabnikom dovolijo, da se tudi sami pridružijo',
  'Become member' => 'Postanite član',
  'Cancel membership' => 'Prekliči članstvo',
  'Group membership' => 'Članstvo v skupini',
  'Groups of which I am a member' => 'Skupine, katerih član sem',
  'My Groups' => 'Moje skupine',
  'My groups' => 'Moje skupine',
  'Others groups I can join' => 'Drugim skupinam se lahko pridružim',
);

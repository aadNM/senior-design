<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Brukere har lov til å bli medlem av denne gruppen (eller avslutte) selv',
  'Users can become a member of this group' => 'Brukere kan bli medlem av denne gruppen',
);

<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Kullanıcıların bu gruba üye olmalarına (veya çıkış yapmalarına) izin verilir.',
  'Users can become a member of this group' => 'Kullanıcılar bu gruba üye olabilir',
);

<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Uporabniki lahko sami postanejo član te skupine (ali izstopijo)',
  'Users can become a member of this group' => 'Uporabniki lahko postanejo član te skupine',
);

<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'משתמשים רשאים להיות חברים בקבוצה זו (או לצאת) בעצמם',
  'Users can become a member of this group' => 'משתמשים יכולים להיות חברים בקבוצה זו',
);

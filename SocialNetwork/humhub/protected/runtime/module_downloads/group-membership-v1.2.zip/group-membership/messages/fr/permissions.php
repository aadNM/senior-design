<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Les utilisateurs sont autorisés à devenir eux-mêmes membre de ce groupe (ou à en sortir)',
  'Users can become a member of this group' => 'Les utilisateurs peuvent devenir membre de ce groupe',
);

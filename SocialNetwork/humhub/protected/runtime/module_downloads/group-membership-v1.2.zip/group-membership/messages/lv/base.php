<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Pievieno iespēju noteiktām grupām ļaut lietotājiem pašiem kļūt par dalībniekiem',
  'Become member' => 'Kļūsti par dalībnieku',
  'Cancel membership' => 'Atcelt dalību',
  'Group membership' => 'Dalība grupā',
  'Groups of which I am a member' => 'Grupas, kuru biedrs esmu',
  'My Groups' => 'Manas grupas',
  'My groups' => 'Manas grupas',
  'Others groups I can join' => 'Citas grupas, kurām varu pievienoties',
);

<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => '사용자가 스스로 회원이 될 수 있도록 특정 그룹에 대한 가능성 추가',
  'Become member' => '회원 가입',
  'Cancel membership' => '멤버십 취소',
  'Group membership' => '그룹 멤버십',
  'Groups of which I am a member' => '내가 회원 인 그룹',
  'My Groups' => '내 그룹',
  'My groups' => '내 그룹',
  'Others groups I can join' => '내가 가입 할 수있는 다른 그룹',
);

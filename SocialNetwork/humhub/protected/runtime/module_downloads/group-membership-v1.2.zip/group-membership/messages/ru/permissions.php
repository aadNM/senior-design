<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Пользователи могут сами стать участниками этой группы (или выйти)',
  'Users can become a member of this group' => 'Пользователи могут стать участниками этой группы',
);

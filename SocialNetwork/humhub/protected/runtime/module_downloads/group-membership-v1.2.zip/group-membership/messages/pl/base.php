<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Dodaje możliwość dla niektórych grup, aby użytkownicy mogli sami zostać członkami',
  'Become member' => 'Zostań członkiem',
  'Cancel membership' => 'Anuluj członkostwo',
  'Group membership' => 'Członkostwo w grupie',
  'Groups of which I am a member' => 'Grupy, których jestem członkiem',
  'My Groups' => 'Moje grupy',
  'My groups' => 'Moje grupy',
  'Others groups I can join' => 'Inne grupy, do których mogę dołączyć',
);

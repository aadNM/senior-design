<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Os usuários têm permissão para se tornar um membro deste grupo (ou sair)',
  'Users can become a member of this group' => 'Os usuários podem se tornar um membro deste grupo',
);

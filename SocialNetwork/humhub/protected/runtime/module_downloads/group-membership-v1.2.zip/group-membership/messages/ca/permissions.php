<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Els usuaris poden formar part d’aquest grup (o sortir-ne) ells mateixos',
  'Users can become a member of this group' => 'Els usuaris poden formar part d’aquest grup',
);

<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Tilføjer muligheden for, at bestemte grupper giver brugerne mulighed for selv at blive medlem',
  'Become member' => 'Bliv medlem',
  'Cancel membership' => 'Annuller medlemskab',
  'Group membership' => 'Gruppemedlemskab',
  'Groups of which I am a member' => 'Grupper, som jeg er medlem af',
  'My Groups' => 'Mine grupper',
  'My groups' => 'Mine grupper',
  'Others groups I can join' => 'Andre grupper jeg kan deltage i',
);

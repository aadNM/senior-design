<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Benutzer dürfen selbst Mitglied dieser Gruppe werden (oder diese verlassen)',
  'Users can become a member of this group' => 'Benutzer können Mitglied dieser Gruppe werden',
);

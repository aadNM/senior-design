<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Gebruikers mogen zelf lid worden van deze groep (of verlaten)',
  'Users can become a member of this group' => 'Gebruikers kunnen lid worden van deze groep',
);

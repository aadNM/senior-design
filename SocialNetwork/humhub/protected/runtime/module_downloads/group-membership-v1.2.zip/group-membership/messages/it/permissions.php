<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Gli utenti possono diventare membri di questo gruppo (o uscire) da soli',
  'Users can become a member of this group' => 'Gli utenti possono diventare membri di questo gruppo',
);

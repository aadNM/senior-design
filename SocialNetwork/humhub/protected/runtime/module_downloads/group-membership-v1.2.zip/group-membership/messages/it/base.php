<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Aggiunge la possibilità per alcuni gruppi di consentire agli utenti di diventare membri loro stessi',
  'Become member' => 'Diventa membro',
  'Cancel membership' => 'Annulla abbonamento',
  'Group membership' => 'Appartenenza al gruppo',
  'Groups of which I am a member' => 'Gruppi di cui faccio parte',
  'My Groups' => 'I miei gruppi',
  'My groups' => 'I miei gruppi',
  'Others groups I can join' => 'Altri gruppi a cui posso unirmi',
);

<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Ajoute la possibilité pour certains groupes d\'autoriser les utilisateurs à devenir membres eux-mêmes',
  'Become member' => 'Devenir membre',
  'Cancel membership' => 'Annuler l\'adhésion',
  'Group membership' => 'Appartenance à un groupe',
  'Groups of which I am a member' => 'Groupes dont je suis membre',
  'My Groups' => 'Mes groupes',
  'My groups' => 'Mes groupes',
  'Others groups I can join' => 'Autres groupes que je peux rejoindre',
);

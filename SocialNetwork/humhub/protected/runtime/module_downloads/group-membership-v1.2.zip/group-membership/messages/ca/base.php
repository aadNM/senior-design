<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Afegeix la possibilitat que certs grups permetin als usuaris fer-se membres',
  'Become member' => 'Feu-vos membre',
  'Cancel membership' => 'Cancel·la la subscripció',
  'Group membership' => 'Membres del grup',
  'Groups of which I am a member' => 'Grups dels quals sóc membre',
  'My Groups' => 'Els meus grups',
  'My groups' => 'Els meus grups',
  'Others groups I can join' => 'Altres grups als quals puc unir-me',
);

<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Lietotājiem ir atļauts pašiem kļūt par šīs grupas dalībniekiem (vai iziet)',
  'Users can become a member of this group' => 'Lietotāji var kļūt par šīs grupas dalībniekiem',
);

<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'ユーザーは自分でこのグループのメンバーになる（または終了する）ことができます',
  'Users can become a member of this group' => 'ユーザーはこのグループのメンバーになることができます',
);

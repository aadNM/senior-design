<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'يُسمح للمستخدمين بأن يصبحوا أعضاءً في هذه المجموعة (أو الخروج) بأنفسهم',
  'Users can become a member of this group' => 'يمكن للمستخدمين أن يصبحوا أعضاء في هذه المجموعة',
);

<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => '',
  'Become member' => '',
  'Cancel membership' => '',
  'Group membership' => '',
  'Groups of which I am a member' => '',
  'My Groups' => '',
  'My groups' => '',
  'Others groups I can join' => '',
);

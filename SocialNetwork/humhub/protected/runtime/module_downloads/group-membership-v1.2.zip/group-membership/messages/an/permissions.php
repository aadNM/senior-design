<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => '',
  'Users can become a member of this group' => '',
);

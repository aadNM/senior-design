<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Pengguna diizinkan untuk menjadi anggota grup ini (atau keluar) sendiri',
  'Users can become a member of this group' => 'Pengguna dapat menjadi anggota grup ini',
);

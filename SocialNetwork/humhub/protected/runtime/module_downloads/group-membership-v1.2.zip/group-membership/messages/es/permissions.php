<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Los usuarios pueden convertirse en miembros de este grupo (o salir) ellos mismos',
  'Users can become a member of this group' => 'Los usuarios pueden convertirse en miembros de este grupo',
);

<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Добавя възможността за определени групи да позволят на потребителите сами да станат членове',
  'Become member' => 'Станете член',
  'Cancel membership' => 'Анулиране на членството',
  'Group membership' => 'Членство в група',
  'Groups of which I am a member' => 'Групи, в които съм член',
  'My Groups' => 'Моите групи',
  'My groups' => 'Моите групи',
  'Others groups I can join' => 'В други групи мога да се присъединя',
);

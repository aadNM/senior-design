<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Foydalanuvchilarning o\'zlari a\'zo bo\'lishlariga imkon berish uchun ma\'lum guruhlarga imkoniyat qo\'shadi',
  'Become member' => 'A\'zo bo\'ling',
  'Cancel membership' => 'A\'zolikni bekor qiling',
  'Group membership' => 'Guruhga a\'zolik',
  'Groups of which I am a member' => 'Men a\'zo bo\'lgan guruhlar',
  'My Groups' => 'Mening guruhlarim',
  'My groups' => 'Mening guruhlarim',
  'Others groups I can join' => 'Boshqa guruhlarga qo\'shilishim mumkin',
);

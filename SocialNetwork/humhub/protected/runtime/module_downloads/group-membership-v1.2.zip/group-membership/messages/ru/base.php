<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Добавляет возможность для определенных групп разрешить пользователям самим становиться участниками',
  'Become member' => 'Стать участником',
  'Cancel membership' => 'Отменить членство',
  'Group membership' => 'Членство в группе',
  'Groups of which I am a member' => 'Группы, в которых я состою',
  'My Groups' => 'Мои группы',
  'My groups' => 'Мои группы',
  'Others groups I can join' => 'Другие группы, к которым я могу присоединиться',
);

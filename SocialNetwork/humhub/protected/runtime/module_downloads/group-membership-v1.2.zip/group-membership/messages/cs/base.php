<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Přidává možnost určitým skupinám umožnit uživatelům, aby se sami stali členy',
  'Become member' => 'Staňte se členem',
  'Cancel membership' => 'Zrušit členství',
  'Group membership' => 'Skupinové členství',
  'Groups of which I am a member' => 'Skupiny, kterých jsem členem',
  'My Groups' => 'Moje skupiny',
  'My groups' => 'Moje skupiny',
  'Others groups I can join' => 'Další skupiny, ke kterým se mohu připojit',
);

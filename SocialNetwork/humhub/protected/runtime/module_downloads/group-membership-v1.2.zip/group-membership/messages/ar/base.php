<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'يضيف إمكانية مجموعات معينة للسماح للمستخدمين بأن يصبحوا أعضاء بأنفسهم',
  'Become member' => 'كن عضوا',
  'Cancel membership' => 'إلغاء العضوية',
  'Group membership' => 'عضوية في المجموعة',
  'Groups of which I am a member' => 'المجموعات التي أنا عضو فيها',
  'My Groups' => 'مجموعاتي',
  'My groups' => 'مجموعاتي',
  'Others groups I can join' => 'مجموعات أخرى يمكنني الانضمام إليها',
);

<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Brugere må selv blive medlem af denne gruppe (eller afslutte)',
  'Users can become a member of this group' => 'Brugere kan blive medlem af denne gruppe',
);

<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'ለተወሰኑ ቡድኖች ተጠቃሚዎች እራሳቸው አባል እንዲሆኑ የመፍቀድ እድልን ያክላል',
  'Become member' => 'አባል ይሁኑ',
  'Cancel membership' => 'አባልነትን ሰርዝ',
  'Group membership' => 'የቡድን አባልነት',
  'Groups of which I am a member' => 'እኔ አባል የሆንኩባቸው ቡድኖች',
  'My Groups' => 'የእኔ ቡድኖች',
  'My groups' => 'የእኔ ቡድኖች',
  'Others groups I can join' => 'ሌሎች እኔ ልቀላቀልባቸው እችላለሁ',
);

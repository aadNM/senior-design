<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Korisnicima je dopušteno da sami postanu članovi ove grupe (ili izađu)',
  'Users can become a member of this group' => 'Korisnici mogu postati članovi ove grupe',
);

<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Użytkownicy mogą sami stać się członkami tej grupy (lub wyjść)',
  'Users can become a member of this group' => 'Użytkownicy mogą zostać członkami tej grupy',
);

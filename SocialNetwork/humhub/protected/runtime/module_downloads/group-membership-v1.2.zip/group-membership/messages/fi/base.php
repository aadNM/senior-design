<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Lisää tietyille ryhmille mahdollisuuden sallia käyttäjien tulla jäseniksi itse',
  'Become member' => 'Liity jäseneksi',
  'Cancel membership' => 'Peruuta jäsenyys',
  'Group membership' => 'Ryhmäjäsenyys',
  'Groups of which I am a member' => 'Ryhmät, joiden jäsen olen',
  'My Groups' => 'Omat ryhmät',
  'My groups' => 'Ryhmäni',
  'Others groups I can join' => 'Muut ryhmät, joihin voin liittyä',
);

<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => '允许用户自己成为该组的成员（或退出）',
  'Users can become a member of this group' => '用户可以成为该组的成员',
);

<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Prideda galimybę tam tikroms grupėms leisti vartotojams patiems tapti nariais',
  'Become member' => 'Tapk nariu',
  'Cancel membership' => 'Atšaukti narystę',
  'Group membership' => 'Grupės narystė',
  'Groups of which I am a member' => 'Grupės, kurių narys esu',
  'My Groups' => 'Mano grupės',
  'My groups' => 'Mano grupės',
  'Others groups I can join' => 'Kitos grupės, prie kurių galiu prisijungti',
);

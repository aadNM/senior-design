<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Používatelia sa môžu stať členmi tejto skupiny (alebo ju môžu opustiť) sami',
  'Users can become a member of this group' => 'Členmi tejto skupiny sa môžu stať používatelia',
);

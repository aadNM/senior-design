<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Προσθέτει τη δυνατότητα για ορισμένες ομάδες να επιτρέπουν στους χρήστες να γίνουν μέλη τους',
  'Become member' => 'Γίνετε μέλος',
  'Cancel membership' => 'Ακύρωση συνδρομής',
  'Group membership' => 'Μέλη ομάδας',
  'Groups of which I am a member' => 'Ομάδες των οποίων είμαι μέλος',
  'My Groups' => 'Οι Ομάδες μου',
  'My groups' => 'Οι ομάδες μου',
  'Others groups I can join' => 'Άλλες ομάδες στις οποίες μπορώ να εγγραφώ',
);

<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Vartotojams leidžiama patiems tapti šios grupės nariais (arba išeiti)',
  'Users can become a member of this group' => 'Vartotojai gali tapti šios grupės nariais',
);

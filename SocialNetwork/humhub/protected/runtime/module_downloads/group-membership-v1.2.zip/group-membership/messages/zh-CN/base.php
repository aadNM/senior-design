<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => '增加了某些组允许用户自己成为成员的可能性',
  'Become member' => '成为会员',
  'Cancel membership' => '取消会员资格',
  'Group membership' => '团体会员',
  'Groups of which I am a member' => '我所属的群组',
  'My Groups' => '我的群组',
  'My groups' => '我的群组',
  'Others groups I can join' => '我可以加入的其他群组',
);

<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'ผู้ใช้ได้รับอนุญาตให้เป็นสมาชิกของกลุ่มนี้ (หรือออก) ด้วยตนเอง',
  'Users can become a member of this group' => 'ผู้ใช้สามารถเป็นสมาชิกของกลุ่มนี้',
);

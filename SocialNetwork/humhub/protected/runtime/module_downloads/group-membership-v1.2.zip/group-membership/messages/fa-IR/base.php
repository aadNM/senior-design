<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'این امکان را برای گروه های خاصی اضافه می کند که به کاربران امکان می دهد خودشان عضو شوند',
  'Become member' => 'عضو شدن',
  'Cancel membership' => 'لغو عضویت',
  'Group membership' => 'عضویت در گروه',
  'Groups of which I am a member' => 'گروههایی که من عضو آنها هستم',
  'My Groups' => 'گروه های من',
  'My groups' => 'گروه های من',
  'Others groups I can join' => 'گروه های دیگری که می توانم به آنها بپیوندم',
);

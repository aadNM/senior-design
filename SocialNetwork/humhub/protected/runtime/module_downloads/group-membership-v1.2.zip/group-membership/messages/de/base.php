<?php
return array (
  'Adds the possibility for certain groups to allow users to become member themselves' => 'Fügt bestimmten Gruppen die Möglichkeit hinzu, dass Benutzer selbst Mitglied werden können',
  'Become member' => 'Werden Sie Mitglied',
  'Cancel membership' => 'Mitgliedschaft kündigen',
  'Group membership' => 'Gruppenmitgliedschaft',
  'Groups of which I am a member' => 'Gruppen, in denen ich Mitglied bin',
  'My Groups' => 'Meine Gruppen',
  'My groups' => 'Meine Gruppen',
  'Others groups I can join' => 'Andere Gruppen, denen ich beitreten kann',
);

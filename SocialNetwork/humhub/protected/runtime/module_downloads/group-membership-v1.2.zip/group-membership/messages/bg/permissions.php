<?php
return array (
  'Users are allowed to become a member of this group (or exit) themselves' => 'Потребителите имат право сами да станат член на тази група (или да излязат)',
  'Users can become a member of this group' => 'Потребителите могат да станат членове на тази група',
);

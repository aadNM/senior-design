# Licences

- HumHub licences at: https://www.humhub.com/licences


©2018 Google LLC All rights reserved. Google and the Google logo are registered trademarks of Google LLC.
